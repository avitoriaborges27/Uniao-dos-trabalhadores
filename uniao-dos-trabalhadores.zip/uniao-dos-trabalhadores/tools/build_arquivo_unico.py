"""Gera dist/uniao-dos-trabalhadores.html: o app inteiro em um único arquivo (CSS e JS embutidos), pronto para hospedar ou publicar."""
import re, pathlib
root = pathlib.Path(__file__).resolve().parent.parent
css = (root / 'css/style.css').read_text(encoding='utf-8')
css = re.sub(r"@font-face\{[^}]*\}\n?", "", css)          # fontes locais não vão no arquivo único; usa Inter se instalada, senão fonte do sistema
js = "\n".join((root / f'js/{n}.js').read_text(encoding='utf-8') for n in ['icons', 'db', 'ui', 'pages', 'calls', 'actions', 'app'])
assert '</script' not in js.lower()
html = f"""<title>União dos Trabalhadores</title>
<meta name="description" content="Plataforma que conecta profissionais autônomos a clientes.">
<style>
{css}
</style>
<div id="app" aria-live="off"></div>
<div id="modal-root"></div>
<div id="call-root" class="call-root" hidden></div>
<div id="toasts" class="toasts" role="status" aria-live="polite"></div>
<script>
{js}
</script>
"""
out = root / 'dist/uniao-dos-trabalhadores.html'
out.write_text(html, encoding='utf-8'); print(out, round(len(html.encode())/1024), 'KB')
