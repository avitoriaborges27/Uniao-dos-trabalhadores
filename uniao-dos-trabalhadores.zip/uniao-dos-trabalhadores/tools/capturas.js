/* Gera as capturas de tela REAIS do aplicativo executando os fluxos de uso (sem edição, sem moldura).
   Uso:  node tools/capturas.js [URL]   (padrão: http://localhost:8765/index.html)
   Requer: Node + Playwright (npm i playwright) e o app servido localmente (ver README).
   Saída: pasta capturas/ — PNG 2x (celular 390x844 e computador 1440x900). */
const { chromium } = require('playwright');
const fs = require('fs'); const path = require('path');
const URL = process.argv[2] || 'http://localhost:8765/index.html';
const OUT = path.join(__dirname, '..', 'capturas'); fs.mkdirSync(OUT, { recursive: true });
const MOBILE = { width: 390, height: 844 }; const DESK = { width: 1440, height: 900 };
let n = 0;
const shot = async (p, name, opts = {}) => { await p.waitForTimeout(450); if (!opts.keepToast) await p.evaluate(() => { const t = document.getElementById('toasts'); if (t) t.innerHTML = ''; }); const f = `${String(++n).padStart(2, '0')}-${name}.png`; await p.screenshot({ path: path.join(OUT, f), fullPage: !!opts.full }); console.log('capturada', f); };

(async () => {
  fs.readdirSync(OUT).filter((f) => f.endsWith('.png')).forEach((f) => fs.unlinkSync(path.join(OUT, f)));
  const browser = await chromium.launch({ args: ['--lang=pt-BR', '--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });
  const newCtx = (vp, extra = {}) => browser.newContext({ viewport: vp, deviceScaleFactor: 2, locale: 'pt-BR', timezoneId: 'America/Sao_Paulo', permissions: ['microphone'], ...extra });
  const go = async (p, h) => { await p.goto(URL + h); await p.waitForTimeout(250); };

  /* ---------- 1. Cadastro e escolha de modo (conta nova, dados vazios) ---------- */
  let ctx = await newCtx(MOBILE); let p = await ctx.newPage();
  await go(p, '#/welcome'); await shot(p, 'cadastro-boas-vindas');
  await go(p, '#/login'); await shot(p, 'cadastro-entrar');
  await go(p, '#/signup');
  await p.fill('input[name=name]', 'Mariana Costa'); await p.fill('input[name=email]', 'mariana@exemplo.com'); await p.fill('input[name=password]', 'senha123'); await p.fill('input[name=city]', 'Bragança - PA'); await p.check('input[name=terms]');
  await shot(p, 'cadastro-criar-conta');
  await p.click('form[data-form=signup] button.primary'); await p.waitForSelector('.mode-cards'); await shot(p, 'modo-escolha');
  await p.click('[data-mode=profissional]'); await p.waitForTimeout(400); await shot(p, 'modo-ativar-perfil-profissional');
  await ctx.close();

  /* ---------- 2. Fluxo cliente x profissional (dados de demonstração) ---------- */
  ctx = await newCtx(MOBILE); const A = await ctx.newPage(); const B = await ctx.newPage();
  await go(A, '#/login'); await A.click('[data-email="juliana@demo.com"]'); await A.waitForURL(/#\/inicio/);
  await go(B, '#/login'); await B.click('[data-email="carlos@demo.com"]'); await B.waitForURL(/#\/inicio/);

  await A.bringToFront(); await go(A, '#/inicio'); await shot(A, 'cliente-feed');
  await go(A, '#/buscar'); await shot(A, 'cliente-buscar');
  await A.fill('[data-input=search-q]', 'Carlos'); await A.locator('#results a[href^="#/pro/"]').first().click(); await A.waitForSelector('text=Serviços e preços');
  await shot(A, 'cliente-perfil-publico-profissional'); await shot(A, 'cliente-perfil-publico-completo', { full: true });
  await A.click('[data-act=request]'); await A.waitForSelector('form[data-form=request-order]'); await A.waitForSelector('#slots button:not([disabled])');
  await A.locator('#slots button:not([disabled])').first().click(); await A.fill('textarea[name=notes]', 'Corte degradê, por favor.');
  await shot(A, 'cliente-solicitar-servico');
  await A.click('form[data-form=request-order] button.primary'); await A.waitForTimeout(600);
  await go(A, '#/pedidos'); await shot(A, 'cliente-pedidos');

  /* chat (cliente → profissional) */
  await go(A, '#/chat'); await shot(A, 'chat-lista');
  await A.locator('a[href^="#/chat/"]').first().click(); await A.waitForSelector('#msgs');
  await A.fill('form[data-form=send-msg] input[name=text]', 'Olá Carlos! Posso levar uma foto de referência?'); await A.press('form[data-form=send-msg] input[name=text]', 'Enter');
  await A.click('[data-act=rec-start]'); await A.waitForTimeout(1300); await shot(A, 'chat-gravando-voz'); await A.click('[data-act=rec-send]');
  await B.bringToFront(); await B.waitForTimeout(500); await go(B, '#/chat'); await B.locator('a[href^="#/chat/"]').first().click(); await B.waitForSelector('#msgs');
  await B.fill('form[data-form=send-msg] input[name=text]', 'Claro! Pode trazer. Te espero no horário combinado.'); await B.press('form[data-form=send-msg] input[name=text]', 'Enter');
  await A.bringToFront(); await A.waitForTimeout(700); await shot(A, 'chat-conversa-tempo-real');
  await A.click('[data-act=call]'); await B.bringToFront(); await B.waitForTimeout(600); await shot(B, 'chamada-recebida');
  await B.click('#call-root [data-call=accept]'); await B.waitForTimeout(1600); await shot(B, 'chamada-em-andamento');
  await B.click('#call-root [data-call=end]'); await B.waitForTimeout(600);

  /* profissional */
  await go(B, '#/inicio'); await shot(B, 'profissional-painel');
  await go(B, '#/agenda'); await shot(B, 'profissional-agenda-calendario'); await shot(B, 'profissional-agenda-completa', { full: true });
  await go(B, '#/agenda/pedidos'); await shot(B, 'profissional-pedidos-pendentes');
  await B.locator('[data-act=order-accept]').first().click(); await B.waitForTimeout(500);
  await B.locator('[data-act=order-complete]').first().click(); await B.waitForSelector('form[data-form=complete-order]'); await shot(B, 'profissional-concluir-servico');
  await B.fill('form[data-form=complete-order] input[name=value]', '50'); await B.click('form[data-form=complete-order] button.primary'); await B.waitForTimeout(500);
  await go(B, '#/agenda/financeiro'); await shot(B, 'profissional-financeiro-semanal', { full: true });
  for (const [k, nm] of [['mes', 'mensal'], ['ano', 'anual']]) { const b = B.locator(`[data-act=fin-period][data-p=${k}]`); if (await b.count()) { await b.click(); await shot(B, `profissional-financeiro-${nm}`, { full: true }); } }
  await go(B, '#/servicos'); await shot(B, 'profissional-servicos');
  await go(B, '#/inicio'); await B.fill('#post-text', 'Corte degradê finalizado hoje. Horários abertos para a semana!'); await shot(B, 'profissional-nova-publicacao');
  await go(B, '#/editar-perfil'); await shot(B, 'profissional-editar-perfil');
  await go(B, '#/perfil'); await shot(B, 'profissional-menu-perfil');

  /* avaliação (cliente) */
  await A.bringToFront(); await go(A, '#/pedidos'); await A.waitForSelector('[data-act=order-review]');
  await A.locator('[data-act=order-review]').first().click(); await A.waitForSelector('form[data-form=review]');
  await A.locator('.star-input button').nth(4).click(); await A.fill('form[data-form=review] textarea', 'Atendimento excelente e pontual. Recomendo!'); await shot(A, 'cliente-avaliar-servico');
  await A.click('form[data-form=review] button.primary'); await A.waitForTimeout(500);
  await go(A, '#/buscar'); await A.fill('[data-input=search-q]', 'Carlos'); await A.locator('#results a[href^="#/pro/"]').first().click(); await A.waitForSelector('text=Serviços e preços');
  await A.evaluate(() => { const h = [...document.querySelectorAll('h3')].find((x) => /Avalia/i.test(x.textContent)); if (h) h.scrollIntoView(); }); await shot(A, 'cliente-avaliacoes-perfil-publico');
  await go(A, '#/notificacoes'); await shot(A, 'cliente-notificacoes');
  await go(A, '#/favoritos'); await shot(A, 'cliente-favoritos');
  await go(A, '#/perfil'); await shot(A, 'cliente-menu-perfil');
  await go(A, '#/config'); await A.check('[data-k=large]', { force: true }).catch(() => {}); await A.check('[data-k=contrast]', { force: true }).catch(() => {}); await shot(A, 'acessibilidade-texto-maior-alto-contraste');
  await A.uncheck('[data-k=large]', { force: true }).catch(() => {}); await A.uncheck('[data-k=contrast]', { force: true }).catch(() => {});
  await ctx.close();

  /* ---------- 2b. Modo escuro ---------- */
  ctx = await newCtx(MOBILE); const E = await ctx.newPage(); const F = await ctx.newPage();
  await go(E, '#/welcome'); await E.evaluate(() => localStorage.setItem('ut_prefs', JSON.stringify({ theme: 'dark' }))); await E.reload();
  await go(E, '#/login'); await E.click('[data-email="juliana@demo.com"]'); await E.waitForURL(/#\/inicio/); await go(E, '#/inicio'); await shot(E, 'escuro-cliente-feed');
  await go(E, '#/config'); await shot(E, 'escuro-configuracoes-tema');
  await go(F, '#/login'); await F.click('[data-email="carlos@demo.com"]'); await F.waitForURL(/#\/inicio/); await go(F, '#/agenda'); await shot(F, 'escuro-profissional-agenda');
  await ctx.close();

  /* ---------- 3. Versão para computador (RNF04) ---------- */
  ctx = await newCtx(DESK); const C = await ctx.newPage(); const D = await ctx.newPage();
  await go(C, '#/login'); await C.click('[data-email="juliana@demo.com"]'); await C.waitForURL(/#\/inicio/); await go(C, '#/inicio'); await shot(C, 'computador-cliente-feed');
  await go(C, '#/buscar'); await shot(C, 'computador-cliente-buscar');
  await go(D, '#/login'); await D.click('[data-email="carlos@demo.com"]'); await D.waitForURL(/#\/inicio/); await go(D, '#/agenda'); await shot(D, 'computador-profissional-agenda');
  await go(D, '#/agenda/financeiro'); await shot(D, 'computador-profissional-financeiro');
  await browser.close(); console.log('\nConcluído:', n, 'capturas em', OUT);
})().catch((e) => { console.error(e); process.exit(1); });
