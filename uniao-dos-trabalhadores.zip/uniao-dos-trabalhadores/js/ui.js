/* Componentes de interface reutilizáveis: formatação, avatar, estrelas, modal, toast, cartões. */
(function () {
  'use strict';
  const UT = window.UT;
  const { ic, icFill } = UT;
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  UT.esc = esc;
  UT.nl2br = (s) => esc(s).replace(/\n/g, '<br>');
  UT.money = (v) => new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(v || 0);
  UT.fmtDate = (s) => { const [y, m, d] = s.split('-'); return `${d}/${m}/${y}`; };
  UT.fmtDateLong = (s) => new Date(s + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
  UT.fmtDateShort = (s) => new Date(s + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: 'short' }).replace('.', '');
  UT.timeAgo = (ts) => {
    const s = Math.max(1, Math.round((Date.now() - ts) / 1000));
    if (s < 60) return 'agora';
    const m = Math.round(s / 60); if (m < 60) return `há ${m} min`;
    const h = Math.round(m / 60); if (h < 24) return `há ${h} h`;
    const d = Math.round(h / 24); if (d < 7) return `há ${d} d`;
    return new Date(ts).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' }).replace('.', '');
  };
  UT.clock = (ts) => new Date(ts).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  UT.dur = (sec) => `${String(Math.floor(sec / 60)).padStart(2, '0')}:${String(Math.floor(sec % 60)).padStart(2, '0')}`;
  UT.modeLabel = (m) => (m === 'profissional' ? 'Profissional' : m === 'cliente' ? 'Cliente' : '');
  const PIX = 'data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==';

  /* mídia com carregamento tardio (IndexedDB) */
  UT.mediaEl = (item, cls = '', alt = '') => {
    if (item.type === 'video') {
      const src = item.src || UT.Media.url(item.id);
      return `<video class="${cls}" ${item.id ? `data-mid="${item.id}"` : ''} ${src ? `src="${src}"` : ''} controls preload="metadata" playsinline aria-label="Vídeo da publicação"></video>`;
    }
    const src = item.src || UT.Media.url(item.id);
    return `<img class="${cls}" ${item.id ? `data-mid="${item.id}"` : ''} src="${src || PIX}" alt="${esc(alt || 'Foto da publicação')}" loading="lazy" data-act="lightbox">`;
  };

  UT.avatar = (u, size = 44) => {
    if (!u) return `<span class="av" style="--s:${size}px"></span>`;
    const ini = u.name.split(/\s+/).filter(Boolean).slice(0, 2).map((x) => x[0]).join('').toUpperCase();
    const src = u.avatarId ? UT.Media.url(u.avatarId) : '';
    return `<span class="av g${(u.color || 0) % 6}" style="--s:${size}px" aria-hidden="true">${esc(ini)}${u.avatarId ? `<img data-mid="${u.avatarId}" ${src ? `src="${src}"` : ''} alt="">` : ''}</span>`;
  };

  UT.stars = (avg, size = 16) => {
    const n = Math.round(avg);
    let h = '';
    for (let i = 1; i <= 5; i++) h += `<span class="${i <= n ? 'on' : 'off'}">${icFill('star', size)}</span>`;
    return `<span class="stars" role="img" aria-label="${avg ? avg.toFixed(1).replace('.', ',') : 'sem'} de 5 estrelas">${h}</span>`;
  };
  UT.ratingLine = (id) => {
    const r = UT.D.rating(id);
    return r.n ? `<span class="rate-line">${UT.stars(r.avg, 14)}<b>${r.avg.toFixed(1).replace('.', ',')}</b><span class="muted">(${r.n})</span></span>` : '<span class="muted small">Sem avaliações ainda</span>';
  };

  UT.empty = (icon, title, text, action = '') => `<div class="empty">${ic(icon, 40)}<h3>${esc(title)}</h3><p>${esc(text)}</p>${action}</div>`;

  const STATUS = { pendente: ['Pendente', 'amber'], aceito: ['Agendado', 'blue'], concluido: ['Concluído', 'green'], recusado: ['Recusado', 'red'], cancelado: ['Cancelado', 'gray'] };
  UT.pill = (st) => `<span class="pill ${STATUS[st][1]}">${STATUS[st][0]}</span>`;

  /* toast */
  UT.toast = (msg, type = 'info') => {
    const box = document.getElementById('toasts'); if (!box) return;
    const el = document.createElement('div');
    el.className = `toast ${type}`; el.innerHTML = `<span>${esc(msg)}</span>`;
    box.appendChild(el);
    setTimeout(() => { el.classList.add('out'); setTimeout(() => el.remove(), 300); }, type === 'error' ? 5200 : 3600);
  };

  /* modal */
  let lastFocus = null;
  UT.closeModal = () => {
    const w = document.getElementById('modal-root'); if (!w) return;
    w.innerHTML = ''; document.body.classList.remove('has-modal');
    if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
    if (UT._modalClose) { const f = UT._modalClose; UT._modalClose = null; f(); }
  };
  UT.openModal = ({ title, body, wide, onClose }) => {
    const w = document.getElementById('modal-root');
    lastFocus = document.activeElement;
    UT._modalClose = onClose || null;
    w.innerHTML = `<div class="backdrop" data-act="modal-backdrop"><div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true" aria-labelledby="modal-title"><header><h2 id="modal-title">${esc(title)}</h2><button class="icon-btn" data-act="modal-close" aria-label="Fechar">${ic('x')}</button></header><div class="modal-body">${body}</div></div></div>`;
    document.body.classList.add('has-modal');
    const f = w.querySelector('input:not([type=hidden]),select,textarea,button.primary,button');
    setTimeout(() => f && f.focus(), 30);
    return w.querySelector('.modal');
  };
  UT.confirm = ({ title, text, ok = 'Confirmar', danger = false }) => new Promise((resolve) => {
    let done = false;
    const m = UT.openModal({ title, body: `<p class="modal-text">${esc(text)}</p><div class="row end gap"><button class="btn ghost" data-act="modal-close">Cancelar</button><button class="btn ${danger ? 'danger' : 'primary'}" data-act="confirm-ok">${esc(ok)}</button></div>`, onClose: () => { if (!done) resolve(false); } });
    m.querySelector('[data-act=confirm-ok]').addEventListener('click', () => { done = true; UT.closeModal(); resolve(true); });
  });

  /* cartão de publicação (RF06, RF07, RF09) */
  UT.postCard = (p, opts = {}) => {
    const D = UT.D; const a = D.user(p.authorId); if (!a) return '';
    const meId = UT.session.get(); const mine = p.authorId === meId; const viewer = D.user(meId);
    const myR = p.reactions[meId];
    const counts = {}; Object.values(p.reactions).forEach((k) => { counts[k] = (counts[k] || 0) + 1; });
    const total = Object.values(counts).reduce((s, x) => s + x, 0);
    const emo = UT.REACTIONS.filter((r) => counts[r.k]).sort((x, y) => counts[y.k] - counts[x.k]).slice(0, 3).map((r) => r.e).join('');
    const open = UT.state.openComments.has(p.id);
    const media = p.media.length ? `<div class="media n${Math.min(p.media.length, 4)}">${p.media.slice(0, 4).map((m) => UT.mediaEl(m, 'm-item')).join('')}</div>` : '';
    const cm = p.comments.map((c) => {
      const cu = D.user(c.userId);
      return `<li class="cmt">${UT.avatar(cu, 30)}<div class="cmt-b"><b>${esc(cu ? cu.name : 'Usuário removido')}</b> <span class="muted small">${UT.timeAgo(c.at)}</span><p>${UT.nl2br(c.text)}</p></div>${c.userId === meId || mine ? `<button class="icon-btn sm" data-act="del-comment" data-id="${p.id}" data-cid="${c.id}" aria-label="Excluir comentário">${ic('trash', 16)}</button>` : ''}</li>`;
    }).join('');
    const reacted = myR ? UT.REACTIONS.find((r) => r.k === myR) : null;
    return `<article class="card post" data-id="${p.id}">
      <header class="post-h"><a class="who" href="#/pro/${a.id}">${UT.avatar(a, 44)}<span><b>${esc(a.name)}</b><small>${a.pro ? esc(a.pro.category) + ' · ' : ''}${esc(a.city)} · ${UT.timeAgo(p.at)}</small></span></a>
        ${mine ? `<span class="post-menu"><button class="icon-btn sm" data-act="edit-post" data-id="${p.id}" aria-label="Editar legenda">${ic('edit', 18)}</button><button class="icon-btn sm" data-act="delete-post" data-id="${p.id}" aria-label="Excluir publicação">${ic('trash', 18)}</button></span>` : (viewer && viewer.mode === 'cliente' && a.pro ? `<a class="btn tonal sm" href="#/pro/${a.id}">Contratar</a>` : '')}</header>
      ${p.text ? `<p class="post-t">${UT.nl2br(p.text)}</p>` : ''}${media}
      <div class="post-stats"><span>${total ? `<span class="emo">${emo}</span> ${total}` : ''}</span><span>${p.comments.length ? `${p.comments.length} comentário${p.comments.length > 1 ? 's' : ''}` : ''}${p.shares ? ` · ${p.shares} compartilhamento${p.shares > 1 ? 's' : ''}` : ''}</span></div>
      <div class="post-actions">
        <div class="react"><button class="act ${myR ? 'on' : ''}" data-act="react-toggle" data-id="${p.id}" aria-pressed="${myR ? 'true' : 'false'}">${reacted ? `<span class="emo">${reacted.e}</span>` : ic('heart', 19)}<span>${reacted ? reacted.l : 'Reagir'}</span></button>
          <div class="pop" role="group" aria-label="Escolher reação">${UT.REACTIONS.map((r) => `<button data-act="react" data-id="${p.id}" data-k="${r.k}" title="${r.l}" aria-label="${r.l}">${r.e}</button>`).join('')}</div></div>
        <button class="act" data-act="toggle-comments" data-id="${p.id}" aria-expanded="${open}">${ic('chat', 19)}<span>Comentar</span></button>
        <button class="act" data-act="share" data-id="${p.id}">${ic('share', 19)}<span>Compartilhar</span></button>
      </div>
      <div class="comments" ${open ? '' : 'hidden'}>${cm ? `<ul>${cm}</ul>` : ''}
        <form class="cmt-form" data-form="comment" data-id="${p.id}"><label class="sr" for="c-${p.id}">Escreva um comentário</label><input id="c-${p.id}" name="text" placeholder="Escreva um comentário…" autocomplete="off" maxlength="500"><button class="icon-btn accent" aria-label="Enviar comentário">${ic('send', 18)}</button></form></div>
    </article>`;
  };

  /* cartão de pedido (agenda, pedidos do cliente e chat) */
  UT.orderCard = (o, viewerId, opts = {}) => {
    const D = UT.D; const viewerIsPro = viewerId === o.proId;
    const other = viewerIsPro ? (o.clientId ? D.user(o.clientId) : null) : D.user(o.proId);
    const name = other ? other.name : o.clientName || 'Cliente externo';
    const rv = D.reviewOfOrder(o.id);
    let act = '';
    if (viewerIsPro) {
      if (o.status === 'pendente') act = `<button class="btn primary sm" data-act="order-accept" data-id="${o.id}">${ic('check', 16)} Aceitar</button><button class="btn ghost sm" data-act="order-refuse" data-id="${o.id}">Recusar</button>`;
      if (o.status === 'aceito') act = `<button class="btn primary sm" data-act="order-complete" data-id="${o.id}">${ic('check', 16)} Concluir</button><button class="btn ghost sm" data-act="order-cancel" data-id="${o.id}">Cancelar</button>`;
    } else {
      if (o.status === 'pendente' || o.status === 'aceito') act = `<button class="btn ghost sm" data-act="order-cancel" data-id="${o.id}">Cancelar pedido</button>`;
      if (o.status === 'concluido' && !rv) act = `<button class="btn primary sm" data-act="order-review" data-id="${o.id}">${ic('star', 16)} Avaliar serviço</button>`;
    }
    if (!opts.inChat && other) act += `<a class="btn ghost sm" href="#/chat/${other.id}">${ic('chat', 16)} Conversar</a>`;
    return `<article class="card order ${opts.inChat ? 'in-chat' : ''}" data-oid="${o.id}">
      <div class="order-top"><div class="order-ico">${ic(o.manual ? 'edit' : 'clipboard', 20)}</div><div class="order-main"><b>${esc(o.serviceName)}</b><span class="muted small">${viewerIsPro ? 'Cliente' : 'Profissional'}: ${esc(name)}</span></div>${UT.pill(o.status)}</div>
      <div class="order-meta"><span>${ic('calendar', 15)} ${UT.fmtDateShort(o.date)}</span><span>${ic('clock', 15)} ${o.time}</span><span>${ic('dollar', 15)} ${o.status === 'concluido' ? UT.money(o.finalValue) : UT.money(o.price)}</span></div>
      ${o.notes ? `<p class="order-notes">“${esc(o.notes)}”</p>` : ''}
      ${rv ? `<div class="order-rv">${UT.stars(rv.stars, 14)}${rv.comment ? `<span class="small">${esc(rv.comment)}</span>` : ''}</div>` : ''}
      ${act ? `<div class="order-act">${act}</div>` : ''}
    </article>`;
  };

  /* estado de interface compartilhado */
  UT.state = { openComments: new Set(), feedCity: null, feedCat: '', search: { q: '', city: null, cat: '', sort: 'rating' }, agenda: { month: null, day: null }, fin: { period: 'semana', offset: 0 }, orderFilter: 'todos', draftMedia: [] };
})();
