/* Ações do usuário: cliques, formulários, campos, gravação de áudio, compartilhamento. */
(function () {
  'use strict';
  const UT = window.UT; const D = UT.D; const { ic, esc, money, toast } = UT;
  const $ = (s, r = document) => r.querySelector(s);
  const me = () => D.user(UT.session.get());
  const fail = (e) => { toast(e && e.message ? e.message : String(e), 'error'); };
  const setErr = (m) => { const el = $('#form-err'); if (el) el.textContent = m || ''; if (m) toast(m, 'error'); };
  const MAX_VIDEO = 60 * 1024 * 1024;

  async function finishLogin(u, remember) {
    UT.session.set(u.id, remember); UT.resetSnap();
    UT.go(u.mode ? '#/inicio' : '#/modo');
  }
  const refreshPage = () => UT.refreshAny();

  /* ---------- solicitar serviço ---------- */
  function slotButtons(proId, date) {
    const sl = D.slots(proId, date);
    return sl.length ? sl.map((t) => `<button type="button" class="slot" data-act="slot" data-t="${t}" aria-pressed="false">${t}</button>`).join('') : '<p class="muted small">Sem horários livres neste dia. Tente outra data.</p>';
  }
  function openRequest(proId) {
    const p = D.user(proId);
    if (!p.pro.services.length) { toast('Este profissional ainda não cadastrou serviços.', 'error'); return; }
    const today = UT.todayStr(); let first = '';
    for (let i = 0; i < 30 && !first; i++) { const d = new Date(); d.setDate(d.getDate() + i); const s = UT.ymd(d); if (D.slots(proId, s).length) first = s; }
    const m = UT.openModal({
      title: `Solicitar serviço — ${p.name.split(' ')[0]}`,
      body: `<form class="form" data-form="request-order" data-pro="${proId}" novalidate>
        <label>Serviço<select name="serviceId">${p.pro.services.map((s) => `<option value="${s.id}">${esc(s.name)} — ${money(s.price)}</option>`).join('')}</select></label>
        <label>Data<input type="date" name="date" min="${today}" value="${first}" required data-change="req-date"></label>
        <fieldset class="fs"><legend>Horário disponível</legend><div id="slots" class="slots">${first ? slotButtons(proId, first) : '<p class="muted small">Sem horários livres nos próximos 30 dias.</p>'}</div></fieldset>
        <input type="hidden" name="time">
        <label>Observações (opcional)<textarea name="notes" rows="2" maxlength="300" placeholder="Endereço, detalhes do serviço…"></textarea></label>
        <p class="form-err" role="alert" id="form-err"></p><button class="btn primary block">Enviar solicitação</button></form>`
    });
    return m;
  }

  /* ---------- compartilhar ---------- */
  function openShare(postId) {
    const u = me(); const contacts = new Set(D.convs(u.id).map((c) => c.other)); D.favs(u.id).forEach((f) => contacts.add(f));
    const link = location.href.split('#')[0] + '#/post/' + postId;
    UT.openModal({
      title: 'Compartilhar publicação',
      body: `<label>Link<input readonly value="${esc(link)}" id="share-link" onfocus="this.select()"></label><button class="btn tonal block" data-act="share-copy" data-id="${postId}">${ic('share', 18)} Copiar link</button>
        <h3 class="sec">Enviar para um contato</h3>${[...contacts].filter((c) => D.user(c) && c !== u.id).length ? `<ul class="share-list">${[...contacts].filter((c) => D.user(c) && c !== u.id).map((c) => { const x = D.user(c); return `<li><button class="share-row" data-act="share-send" data-id="${postId}" data-to="${c}">${UT.avatar(x, 38)}<span><b>${esc(x.name)}</b></span>${ic('send', 18)}</button></li>`; }).join('')}</ul>` : '<p class="muted small">Você ainda não tem conversas ou favoritos para enviar.</p>'}`
    });
  }

  /* ---------- gravação de voz ---------- */
  let rec = null;
  UT.stopRec = (send) => {
    if (!rec) return; const r = rec; rec = null; clearInterval(r.timer);
    r.mr.onstop = async () => {
      r.stream.getTracks().forEach((t) => t.stop());
      if (send && r.chunks.length) {
        try {
          const blob = new Blob(r.chunks, { type: r.mr.mimeType || 'audio/webm' });
          const id = await UT.Media.put(blob);
          D.send({ from: r.from, to: r.to, type: 'audio', mediaId: id, duration: (Date.now() - r.t0) / 1000 });
          UT.updateThread(true);
        } catch (e) { fail(e); }
      }
    };
    try { r.mr.stop(); } catch (e) { r.stream.getTracks().forEach((t) => t.stop()); }
    const bar = $('#recbar'); const f = $('form.composer'); if (bar) bar.hidden = true; if (f) f.hidden = false;
  };
  async function recStart() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) { toast('Gravação de áudio não suportada neste navegador.', 'error'); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream); const chunks = []; mr.ondataavailable = (e) => { if (e.data && e.data.size) chunks.push(e.data); };
      const t0 = Date.now();
      rec = { mr, stream, chunks, t0, from: me().id, to: UT.cur.parts[1], timer: setInterval(() => { const t = $('#rec-time'); if (t) t.textContent = UT.dur((Date.now() - t0) / 1000); }, 250) };
      mr.start(250);
      $('#recbar').hidden = false; $('form.composer').hidden = true;
    } catch (e) { toast('Não foi possível acessar o microfone. Verifique a permissão do navegador.', 'error'); }
  }

  /* ---------- localização ---------- */
  const hav = (a, b) => { const R = Math.PI / 180; const dx = (b[0] - a[0]) * R; const dy = (b[1] - a[1]) * R; const x = Math.sin(dx / 2) ** 2 + Math.cos(a[0] * R) * Math.cos(b[0] * R) * Math.sin(dy / 2) ** 2; return 2 * Math.asin(Math.sqrt(x)); };
  function useLocation() {
    if (!navigator.geolocation) { toast('Seu navegador não oferece geolocalização.', 'error'); return; }
    navigator.geolocation.getCurrentPosition((pos) => {
      const c = [pos.coords.latitude, pos.coords.longitude]; let best = null; let bd = 1e9;
      Object.entries(UT.CITIES).forEach(([n, ll]) => { const d = hav(c, ll); if (d < bd) { bd = d; best = n; } });
      UT.state.search.city = best; toast(`Cidade mais próxima da lista: ${best}`, 'success'); UT.refresh();
    }, () => toast('Não foi possível obter sua localização. Escolha a cidade manualmente.', 'error'), { timeout: 8000 });
  }

  /* ---------- modais de formulários ---------- */
  const openComplete = (o) => UT.openModal({ title: 'Concluir serviço', body: `<form class="form" data-form="complete-order" data-id="${o.id}"><p class="muted">${esc(o.serviceName)}</p><label>Valor recebido (R$)<input name="value" type="number" min="0" step="0.01" inputmode="decimal" value="${o.price}" required></label><p class="muted small">O valor informado será registrado automaticamente no faturamento.</p><button class="btn primary green block">Concluir e registrar</button></form>` });
  const openReview = (o) => { const p = D.user(o.proId); UT.openModal({ title: 'Avaliar serviço', body: `<form class="form" data-form="review" data-id="${o.id}"><p class="muted">${esc(o.serviceName)} — ${esc(p.name)}</p><div class="star-input" role="radiogroup" aria-label="Nota de 1 a 5 estrelas">${[1, 2, 3, 4, 5].map((i) => `<button type="button" role="radio" aria-checked="false" aria-label="${i} estrela${i > 1 ? 's' : ''}" data-act="rate-star" data-v="${i}">${UT.icFill('star', 36)}</button>`).join('')}</div><input type="hidden" name="stars" value="0"><label>Comentário (opcional)<textarea name="comment" rows="3" maxlength="400" placeholder="Conte como foi sua experiência"></textarea></label><p class="form-err" role="alert" id="form-err"></p><button class="btn primary block">Enviar avaliação</button></form>` }); };
  const openManual = () => { const A = UT.state.agenda; UT.openModal({ title: 'Novo compromisso', body: `<form class="form" data-form="manual"><label>Título<input name="title" required maxlength="60" placeholder="Ex.: Corte — cliente de balcão"></label><label>Nome do cliente (opcional)<input name="clientName" maxlength="60"></label><div class="row gap"><label class="grow">Data<input type="date" name="date" value="${A.day || UT.todayStr()}" required></label><label class="grow">Hora<input type="time" name="time" value="09:00" required></label></div><label>Valor previsto (R$)<input name="value" type="number" min="0" step="0.01" inputmode="decimal" value="0"></label><p class="form-err" role="alert" id="form-err"></p><button class="btn primary green block">Adicionar à agenda</button></form>` }); };
  const openService = (s) => UT.openModal({ title: s ? 'Editar serviço' : 'Novo serviço', body: `<form class="form" data-form="service" data-id="${s ? s.id : ''}"><label>Nome do serviço<input name="name" required maxlength="60" value="${s ? esc(s.name) : ''}"></label><label>Preço (R$)<input name="price" type="number" min="0" step="0.01" inputmode="decimal" required value="${s ? s.price : ''}"></label><p class="form-err" role="alert" id="form-err"></p><button class="btn primary green block">Salvar serviço</button></form>` });

  /* ---------- cliques ---------- */
  const A = {
    skip: (el, e) => { e.preventDefault(); const m = $('#main'); if (m) m.focus(); },
    'modal-close': () => UT.closeModal(),
    'modal-backdrop': (el, e) => { if (e.target === el) UT.closeModal(); },
    'lb-close': () => { const l = $('.lightbox'); if (l) l.remove(); },
    lightbox: (el) => {
      const l = document.createElement('div'); l.className = 'lightbox'; l.dataset.act = 'lb-close';
      l.innerHTML = `<button class="icon-btn" aria-label="Fechar" data-act="lb-close">${ic('x', 26)}</button><img src="${el.currentSrc || el.src}" alt="${esc(el.alt)}">`; document.body.appendChild(l);
    },
    'demo-login': async (el) => { try { const u = await D.login(el.dataset.email, 'demo123'); finishLogin(u, false); } catch (e) { fail(e); } },
    'choose-mode': (el) => {
      const u = me(); const m = el.dataset.mode;
      if (m === 'profissional' && !u.pro) return UT.go('#/ativar');
      D.setMode(u.id, m); UT.go('#/inicio');
    },
    'swap-mode': () => {
      const u = me(); const m = u.mode === 'profissional' ? 'cliente' : 'profissional';
      if (m === 'profissional' && !u.pro) return UT.go('#/ativar');
      D.setMode(u.id, m); toast(`Modo ${UT.modeLabel(m)} ativado.`, 'success'); UT.go('#/inicio');
    },
    logout: async () => { if (await UT.confirm({ title: 'Sair da conta', text: 'Deseja realmente sair?', ok: 'Sair' })) { UT.session.clear(); UT.go('#/welcome'); } },
    'feed-cat': (el) => { UT.state.feedCat = el.dataset.cat; UT.refresh(); },
    'order-filter': (el) => { UT.state.orderFilter = el.dataset.f; UT.refresh(); },
    fav: (el) => { const on = D.toggleFav(me().id, el.dataset.id); toast(on ? 'Adicionado aos favoritos.' : 'Removido dos favoritos.', 'success'); UT.refresh(); },
    'use-location': () => useLocation(),
    request: (el) => openRequest(el.dataset.id),
    slot: (el) => {
      document.querySelectorAll('.slot').forEach((b) => { b.classList.remove('on'); b.setAttribute('aria-pressed', 'false'); });
      el.classList.add('on'); el.setAttribute('aria-pressed', 'true'); $('form[data-form=request-order] input[name=time]').value = el.dataset.t;
    },
    react: (el) => { D.react(el.dataset.id, me().id, el.dataset.k); UT.refreshPosts(); },
    'react-toggle': (el) => { const p = D.post(el.dataset.id); D.react(el.dataset.id, me().id, p.reactions[me().id] || 'like'); UT.refreshPosts(); },
    'toggle-comments': (el) => {
      const id = el.dataset.id; const s = UT.state.openComments; if (s.has(id)) s.delete(id); else s.add(id);
      const c = el.closest('.post').querySelector('.comments'); c.hidden = !s.has(id); el.setAttribute('aria-expanded', s.has(id));
      if (s.has(id)) c.querySelector('input').focus();
    },
    share: (el) => openShare(el.dataset.id),
    'share-copy': async (el) => {
      const link = $('#share-link').value;
      try { await navigator.clipboard.writeText(link); } catch (e) { $('#share-link').select(); document.execCommand && document.execCommand('copy'); }
      D.sharePost(el.dataset.id); toast('Link copiado!', 'success'); UT.closeModal(); UT.refreshPosts();
    },
    'share-send': (el) => { D.send({ from: me().id, to: el.dataset.to, type: 'post', postId: el.dataset.id }); D.sharePost(el.dataset.id); toast('Publicação enviada na conversa.', 'success'); UT.closeModal(); UT.refreshPosts(); },
    'edit-post': (el) => {
      const p = D.post(el.dataset.id);
      UT.openModal({ title: 'Editar legenda', body: `<form class="form" data-form="edit-post" data-id="${p.id}"><label>Legenda<textarea name="text" rows="4" maxlength="800">${esc(p.text)}</textarea></label><button class="btn primary block">Salvar</button></form>` });
    },
    'delete-post': async (el) => {
      if (!(await UT.confirm({ title: 'Excluir publicação', text: 'Esta ação não pode ser desfeita.', ok: 'Excluir', danger: true }))) return;
      const ids = D.deletePost(el.dataset.id); ids.forEach((i) => UT.Media.del(i)); toast('Publicação excluída.', 'success'); UT.refreshPosts(); if (UT.view.title === 'Publicação') UT.go('#/inicio');
    },
    'del-comment': (el) => { D.delComment(el.dataset.id, el.dataset.cid); UT.refreshPosts(); },
    'draft-remove': (el) => { const [m] = UT.state.draftMedia.splice(+el.dataset.i, 1); if (m && m.id) UT.Media.del(m.id); $('#draft').innerHTML = UT.draftHTML(); },
    'order-accept': (el) => { try { D.orderAct(el.dataset.id, 'accept', me().id); toast('Pedido aceito. Ele já está na sua agenda.', 'success'); refreshPage(); } catch (e) { fail(e); } },
    'order-refuse': async (el) => { if (await UT.confirm({ title: 'Recusar pedido', text: 'O cliente será avisado.', ok: 'Recusar', danger: true })) { try { D.orderAct(el.dataset.id, 'refuse', me().id); refreshPage(); } catch (e) { fail(e); } } },
    'order-cancel': async (el) => { if (await UT.confirm({ title: 'Cancelar pedido', text: 'O horário será liberado e a outra parte será avisada.', ok: 'Cancelar pedido', danger: true })) { try { D.orderAct(el.dataset.id, 'cancel', me().id); refreshPage(); } catch (e) { fail(e); } } },
    'order-complete': (el) => openComplete(D.order(el.dataset.id)),
    'order-review': (el) => openReview(D.order(el.dataset.id)),
    'rate-star': (el) => {
      const v = +el.dataset.v; $('form[data-form=review] input[name=stars]').value = v;
      document.querySelectorAll('.star-input button').forEach((b) => { const on = +b.dataset.v <= v; b.classList.toggle('on', on); b.setAttribute('aria-checked', +b.dataset.v === v); });
    },
    'cal-day': (el) => { UT.state.agenda.day = el.dataset.date; $('#cal').innerHTML = UT.calendarHTML(); },
    'cal-prev': () => { const m = UT.state.agenda.month; const d = new Date(m.y, m.m - 1, 1); UT.state.agenda.month = { y: d.getFullYear(), m: d.getMonth() }; $('#cal').innerHTML = UT.calendarHTML(); },
    'cal-next': () => { const m = UT.state.agenda.month; const d = new Date(m.y, m.m + 1, 1); UT.state.agenda.month = { y: d.getFullYear(), m: d.getMonth() }; $('#cal').innerHTML = UT.calendarHTML(); },
    'new-manual': () => openManual(),
    'toggle-block': () => { const b = D.toggleBlocked(me().id, UT.state.agenda.day); toast(b ? 'Dia bloqueado para novos pedidos.' : 'Dia liberado.', 'success'); $('#cal').innerHTML = UT.calendarHTML(); },
    'fin-period': (el) => { UT.state.fin = { period: el.dataset.p, offset: 0 }; $('#fin').innerHTML = UT.financeHTML(); },
    'fin-prev': () => { UT.state.fin.offset -= 1; $('#fin').innerHTML = UT.financeHTML(); },
    'fin-next': () => { if (UT.state.fin.offset < 0) UT.state.fin.offset += 1; $('#fin').innerHTML = UT.financeHTML(); },
    'svc-new': () => openService(null),
    'svc-edit': (el) => openService(me().pro.services.find((s) => s.id === el.dataset.id)),
    'svc-del': async (el) => { if (await UT.confirm({ title: 'Excluir serviço', text: 'Pedidos já realizados não são afetados.', ok: 'Excluir', danger: true })) { D.deleteService(me().id, el.dataset.id); UT.refresh(); } },
    call: (el) => UT.startCall(el.dataset.id),
    'rec-start': () => recStart(),
    'rec-cancel': () => UT.stopRec(false),
    'rec-send': () => UT.stopRec(true),
    'reset-demo': async () => { if (await UT.confirm({ title: 'Restaurar demonstração', text: 'Todos os dados atuais serão substituídos pelos dados fictícios de demonstração.', ok: 'Restaurar', danger: true })) { await D.resetDemo(); UT.session.clear(); toast('Dados de demonstração restaurados.', 'success'); UT.go('#/welcome'); } },
    wipe: async () => { if (await UT.confirm({ title: 'Apagar todos os dados', text: 'O aplicativo ficará vazio, sem usuários. Você precisará criar uma conta nova.', ok: 'Apagar tudo', danger: true })) { D.wipe(); UT.session.clear(); toast('Dados apagados.', 'success'); UT.go('#/welcome'); } },
    'del-account': async () => { if (await UT.confirm({ title: 'Excluir conta', text: 'Sua conta, publicações, pedidos e mensagens serão removidos neste navegador.', ok: 'Excluir conta', danger: true })) { D.deleteAccount(me().id); UT.session.clear(); UT.go('#/welcome'); } }
  };
  document.addEventListener('click', (e) => {
    const el = e.target.closest('[data-act]'); if (!el) return;
    const f = A[el.dataset.act]; if (!f) return;
    try { const r = f(el, e); if (r && r.catch) r.catch(fail); } catch (err) { fail(err); }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') { if ($('.lightbox')) A['lb-close'](); else if (document.body.classList.contains('has-modal')) UT.closeModal(); }
  });
  /* pressionar e segurar abre as reações (toque) */
  let lp = null;
  document.addEventListener('touchstart', (e) => { const r = e.target.closest('.react'); if (!r) return; lp = setTimeout(() => { r.classList.add('open'); }, 450); }, { passive: true });
  document.addEventListener('touchend', () => clearTimeout(lp));
  document.addEventListener('click', (e) => { document.querySelectorAll('.react.open').forEach((r) => { if (!r.contains(e.target) || e.target.closest('.pop button')) r.classList.remove('open'); }); });

  /* ---------- formulários ---------- */
  const F = {
    login: async (f) => {
      const d = new FormData(f);
      try { const u = await D.login(d.get('email'), d.get('password')); await finishLogin(u, !!d.get('remember')); } catch (e) { setErr(e.message); }
    },
    signup: async (f) => {
      const d = new FormData(f);
      if (String(d.get('name')).trim().length < 3) return setErr('Informe seu nome completo.');
      if (!/^\S+@\S+\.\S+$/.test(d.get('email'))) return setErr('Informe um e-mail válido.');
      if (String(d.get('password')).length < 6) return setErr('A senha deve ter ao menos 6 caracteres.');
      if (!String(d.get('city')).trim()) return setErr('Informe sua cidade.');
      if (!d.get('terms')) return setErr('É necessário aceitar os termos para criar a conta.');
      try { const u = await D.register({ name: d.get('name'), email: d.get('email'), password: d.get('password'), city: d.get('city') }); UT.session.set(u.id, false); UT.resetSnap(); UT.go('#/modo'); } catch (e) { setErr(e.message); }
    },
    'activate-pro': (f) => {
      const d = new FormData(f);
      if (!d.get('category')) return setErr('Selecione sua profissão.');
      if (!String(d.get('description')).trim() || !String(d.get('serviceName')).trim()) return setErr('Preencha a descrição e o primeiro serviço.');
      if (!(Number(d.get('price')) >= 0) || d.get('price') === '') return setErr('Informe um preço válido.');
      D.activatePro(me().id, { category: d.get('category'), description: String(d.get('description')).trim(), serviceName: String(d.get('serviceName')).trim(), price: d.get('price') });
      toast('Perfil profissional ativado!', 'success'); UT.go('#/inicio');
    },
    'edit-profile': (f) => {
      const d = new FormData(f); const u = me();
      if (String(d.get('name')).trim().length < 3) return setErr('Informe seu nome.');
      if (!String(d.get('city')).trim()) return setErr('Informe sua cidade.');
      D.updateUser(u.id, { name: String(d.get('name')).trim(), city: String(d.get('city')).trim() });
      if (u.pro) D.updatePro(u.id, { category: d.get('category'), description: String(d.get('description')).trim() });
      toast('Perfil atualizado.', 'success'); UT.go('#/perfil');
    },
    comment: (f) => { const t = f.elements.text.value; if (!t.trim()) return; try { D.comment(f.dataset.id, me().id, t); UT.state.openComments.add(f.dataset.id); f.reset(); UT.refreshPosts(true); const i = $(`.post[data-id="${f.dataset.id}"] input[name=text]`); if (i) i.focus(); } catch (e) { fail(e); } },
    'edit-post': (f) => { D.updatePost(f.dataset.id, f.elements.text.value); UT.closeModal(); toast('Legenda atualizada.', 'success'); UT.refreshPosts(); },
    'new-post': (f) => {
      try { D.createPost({ authorId: me().id, text: f.elements.text.value, media: UT.state.draftMedia.slice() }); } catch (e) { return fail(e); }
      UT.state.draftMedia = []; toast('Publicação criada!', 'success'); UT.refresh();
    },
    'send-msg': (f) => { const t = f.elements.text.value.trim(); if (!t) return; D.send({ from: me().id, to: f.dataset.to, type: 'text', text: t }); f.reset(); UT.updateThread(true); },
    avail: (f) => {
      const w = {};
      for (let i = 0; i < 7; i++) { w[i] = { on: f.elements['on' + i].checked, start: f.elements['start' + i].value, end: f.elements['end' + i].value }; if (w[i].on && w[i].start >= w[i].end) return toast(`${UT.WEEKDAYS[i]}: o horário final deve ser depois do inicial.`, 'error'); }
      D.setAvail(me().id, w); toast('Horários de atendimento salvos.', 'success');
    },
    'request-order': (f) => {
      const d = new FormData(f);
      if (!d.get('time')) return setErr('Escolha um horário disponível.');
      try { D.createOrder({ clientId: me().id, proId: f.dataset.pro, serviceId: d.get('serviceId'), date: d.get('date'), time: d.get('time'), notes: d.get('notes') }); UT.closeModal(); toast('Solicitação enviada! Acompanhe pelo chat.', 'success'); UT.go('#/chat/' + f.dataset.pro); } catch (e) { setErr(e.message); }
    },
    'complete-order': (f) => { try { D.orderAct(f.dataset.id, 'complete', me().id, { value: f.elements.value.value }); UT.closeModal(); toast('Serviço concluído e valor registrado no faturamento.', 'success'); refreshPage(); } catch (e) { fail(e); } },
    review: (f) => { const s = +f.elements.stars.value; if (!s) return setErr('Escolha de 1 a 5 estrelas.'); try { D.addReview({ orderId: f.dataset.id, stars: s, comment: f.elements.comment.value }); UT.closeModal(); toast('Avaliação enviada. Obrigado!', 'success'); refreshPage(); } catch (e) { setErr(e.message); } },
    manual: (f) => { const d = new FormData(f); try { D.createManual({ proId: me().id, title: d.get('title'), clientName: d.get('clientName'), date: d.get('date'), time: d.get('time'), value: d.get('value') }); UT.state.agenda.day = d.get('date'); const [y, m] = d.get('date').split('-'); UT.state.agenda.month = { y: +y, m: +m - 1 }; UT.closeModal(); toast('Compromisso adicionado à agenda.', 'success'); UT.refresh(); } catch (e) { setErr(e.message); } },
    service: (f) => {
      const name = f.elements.name.value.trim(); const price = Number(f.elements.price.value);
      if (!name || !(price >= 0) || f.elements.price.value === '') return setErr('Informe nome e preço válidos.');
      D.saveService(me().id, { id: f.dataset.id || null, name, price }); UT.closeModal(); toast('Serviço salvo.', 'success'); UT.refresh();
    }
  };
  document.addEventListener('submit', (e) => {
    const f = e.target.closest('form[data-form]'); if (!f) return;
    e.preventDefault(); const h = F[f.dataset.form]; if (!h) return;
    try { const r = h(f); if (r && r.catch) r.catch(fail); } catch (err) { fail(err); }
  });

  /* ---------- campos ---------- */
  async function addFiles(files) {
    const st = UT.state; let n = 0;
    for (const file of files) {
      if (st.draftMedia.length >= 4) { toast('Máximo de 4 arquivos por publicação.', 'error'); break; }
      try {
        if (file.type.startsWith('image/')) { const b = await UT.resizeImage(file); st.draftMedia.push({ id: await UT.Media.put(b), type: 'image' }); n++; }
        else if (file.type.startsWith('video/')) { if (file.size > MAX_VIDEO) { toast(`"${file.name}" excede 60 MB.`, 'error'); continue; } st.draftMedia.push({ id: await UT.Media.put(file), type: 'video' }); n++; }
        else toast(`"${file.name}": formato não suportado.`, 'error');
      } catch (e) { fail(e); }
    }
    const d = $('#draft'); if (d) d.innerHTML = UT.draftHTML();
  }
  const C = {
    'feed-city': (el) => { UT.state.feedCity = el.value; UT.refresh(); },
    'search-city': (el) => { UT.state.search.city = el.value; UT.refresh(); },
    'search-cat': (el) => { UT.state.search.cat = el.value; UT.refresh(); },
    'search-sort': (el) => { UT.state.search.sort = el.value; UT.refresh(); },
    'req-date': (el) => { const f = el.form; $('#slots').innerHTML = slotButtons(f.dataset.pro, el.value); f.elements.time.value = ''; },
    'post-files': async (el) => { await addFiles([...el.files]); el.value = ''; },
    avatar: async (el) => {
      const file = el.files[0]; if (!file) return;
      try { const b = await UT.resizeImage(file, 480, 0.88); const id = await UT.Media.put(b); const u = me(); if (u.avatarId) UT.Media.del(u.avatarId); D.updateUser(u.id, { avatarId: id }); toast('Foto atualizada.', 'success'); UT.refresh(); } catch (e) { fail(e); }
    },
    pref: (el) => { UT.setPref(el.dataset.k, el.checked); },
    theme: (el) => { UT.setPref('theme', el.value); }
  };
  document.addEventListener('change', (e) => { const el = e.target.closest('[data-change]'); if (el && C[el.dataset.change]) { try { const r = C[el.dataset.change](el); if (r && r.catch) r.catch(fail); } catch (err) { fail(err); } } });
  document.addEventListener('input', (e) => {
    const el = e.target.closest('[data-input]'); if (!el) return;
    if (el.dataset.input === 'search-q') {
      UT.state.search.q = el.value; const r = UT.resultsHTML();
      $('#results').innerHTML = r.html; $('#res-count').textContent = `${r.n} profissional${r.n === 1 ? '' : 'is'} encontrado${r.n === 1 ? '' : 's'}`;
    }
  });
})();
