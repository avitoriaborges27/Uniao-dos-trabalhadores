/* Roteador, estrutura (shell) e atualizações em tempo real. */
(function () {
  'use strict';
  const UT = window.UT; const D = UT.D; const P = UT.pages; const { ic, esc } = UT;
  const $ = (s, r = document) => r.querySelector(s);
  const me = () => D.user(UT.session.get());
  UT.me = me;
  UT.go = (h) => { if (location.hash === h) route(); else location.hash = h; };

  /* preferências do dispositivo (acessibilidade) */
  UT.prefs = () => { try { return JSON.parse(localStorage.getItem('ut_prefs')) || {}; } catch (e) { return {}; } };
  const applyPrefs = () => { const p = UT.prefs(); document.documentElement.dataset.large = p.large ? '1' : '0'; document.documentElement.dataset.contrast = p.contrast ? '1' : '0'; if (p.theme === 'dark' || p.theme === 'light') document.documentElement.dataset.theme = p.theme; else delete document.documentElement.dataset.theme; };
  UT.setPref = (k, v) => { const p = UT.prefs(); p[k] = v; localStorage.setItem('ut_prefs', JSON.stringify(p)); applyPrefs(); };

  const NAV = {
    cliente: [['inicio', 'Início', 'home'], ['buscar', 'Buscar', 'search'], ['chat', 'Chat', 'chat'], ['perfil', 'Perfil', 'user']],
    profissional: [['inicio', 'Início', 'home'], ['chat', 'Chat', 'chat'], ['agenda', 'Agenda', 'calendar'], ['perfil', 'Perfil', 'user']]
  };

  function buildView(parts, u) {
    const [name, a] = parts;
    switch (name || 'inicio') {
      case 'welcome': return P.welcome();
      case 'login': return P.login();
      case 'signup': return P.signup();
      case 'modo': return P.modo();
      case 'ativar': return P.ativar();
      case 'inicio': return P.inicio();
      case 'buscar': return P.buscar();
      case 'pro': return P.pro(a);
      case 'post': return P.post(a);
      case 'chat': return a ? P.thread(a) : P.chat();
      case 'pedidos': return P.pedidos();
      case 'agenda': return P.agenda(a);
      case 'perfil': return P.perfil();
      case 'editar-perfil': return P.editar();
      case 'servicos': return P.servicos();
      case 'publicacoes': return P.publicacoes();
      case 'notificacoes': return P.notificacoes();
      case 'favoritos': return P.favoritos();
      case 'politicas': return P.politicas();
      case 'config': return P.config();
      case 'ajuda': return P.ajuda();
      default: return { title: 'Página não encontrada', back: '#/inicio', nav: 'inicio', html: UT.empty('search', 'Página não encontrada', 'O endereço acessado não existe.', '<a class="btn tonal" href="#/inicio">Ir para o início</a>') };
    }
  }

  function shell(u, v) {
    const items = NAV[u.mode]; const chatN = D.unreadMsgs(u.id); const nN = D.unreadNotifs(u.id); const isPro = u.mode === 'profissional';
    const link = (k, l, i) => `<a href="#/${k}" class="${v.nav === k ? 'on' : ''}" ${v.nav === k ? 'aria-current="page"' : ''}>${ic(i, 24)}<span>${l}</span>${k === 'chat' ? `<span class="badge" data-badge="chat" ${chatN ? '' : 'hidden'}>${chatN}</span>` : ''}</a>`;
    return `<div class="shell ${v.hideNav ? 'no-tabs' : ''}" data-mode="${u.mode}">
      <a class="skip" href="#/" data-act="skip">Ir para o conteúdo</a>
      <aside class="side" aria-label="Navegação principal"><a class="brand" href="#/inicio">${UT.logo(38)}<span>União dos<br>Trabalhadores</span></a>
        <nav>${items.map(([k, l, i]) => link(k, l, i)).join('')}</nav><span class="spacer"></span>
        <button class="swap" data-act="swap-mode">${ic('swap', 18)} Modo ${isPro ? 'Cliente' : 'Profissional'}</button>
        <a class="usercard" href="#/perfil">${UT.avatar(u, 40)}<span><b>${esc(u.name)}</b><small class="mode-label ${isPro ? 'pro' : 'client'}">${UT.modeLabel(u.mode)}</small></span></a></aside>
      <div class="col"><header class="top">
          ${v.back ? `<a class="icon-btn" href="${v.back}" aria-label="Voltar">${ic('chevL', 22)}</a><span class="top-title">${esc(v.title)}</span>` : `<a class="brand m" href="#/inicio">${UT.logo(30)}<span>União dos Trabalhadores</span></a>`}
          <span class="spacer"></span>
          <a class="icon-btn bell" href="#/notificacoes" aria-label="Notificações">${ic('bell', 22)}<span class="badge" data-badge="notif" ${nN ? '' : 'hidden'}>${nN}</span></a>
          <a class="chip-user" href="#/perfil" aria-label="Meu perfil">${UT.avatar(u, 36)}<span class="cu-t"><b>${esc(u.name.split(' ')[0])}</b><small class="mode-label ${isPro ? 'pro' : 'client'}">${UT.modeLabel(u.mode)}</small></span></a></header>
        <main id="main" tabindex="-1">${v.html}</main>
        <nav class="tabbar" aria-label="Navegação principal">${items.map(([k, l, i]) => link(k, l, i)).join('')}</nav></div></div>`;
  }

  function route() {
    UT.stopRec && UT.stopRec(false);
    const parts = (location.hash.replace(/^#\/?/, '').split('?')[0] || '').split('/').filter(Boolean).map(decodeURIComponent);
    const sid = UT.session.get(); const u = sid ? D.user(sid) : null;
    if (sid && !u) UT.session.clear();
    const name = parts[0] || '';
    const go = (h) => { location.replace('#/' + h); };
    if (!u) { if (!['welcome', 'login', 'signup', 'politicas'].includes(name)) return go('welcome'); }
    else {
      if (['welcome', 'login', 'signup'].includes(name)) return go(u.mode ? 'inicio' : 'modo');
      if (!u.mode && !['modo', 'ativar', 'politicas'].includes(name)) return go('modo');
      if (u.mode === 'profissional' && ['buscar', 'favoritos', 'pedidos'].includes(name)) return go('inicio');
      if (u.mode === 'cliente' && ['servicos', 'publicacoes', 'agenda'].includes(name)) return go('inicio');
      if (name === 'ativar' && u.pro) return go('inicio');
    }
    UT.cur = { parts };
    const v = buildView(parts, u);
    if (!u && !v.bare) { v.bare = true; v.html = `<section class="auth"><a class="back-link" href="#/signup">${ic('chevL')} Voltar</a>${v.html}</section>`; }
    UT.view = v;
    document.title = `${v.title} · União dos Trabalhadores`;
    const app = $('#app');
    if (v.bare) { app.className = 'bare'; app.innerHTML = `<div class="bare-wrap">${v.html}</div>`; }
    else { app.className = ''; app.innerHTML = shell(u, v); }
    window.scrollTo(0, 0);
    if (v.after) v.after();
    const m = $('#main') || $('.bare-wrap'); if (m && m.focus) m.focus({ preventScroll: true });
  }

  /* re-renderiza apenas o conteúdo principal, preservando a rolagem */
  UT.refresh = () => {
    const u = me(); if (!u || !UT.cur || !$('#main')) return;
    const y = window.scrollY; const v = buildView(UT.cur.parts, u); UT.view = v;
    $('#main').innerHTML = v.html; window.scrollTo(0, y); UT.updateBadges(); if (v.after) v.after();
  };
  UT.refreshPosts = (force) => {
    document.querySelectorAll('.post').forEach((el) => {
      if (!force && (el.querySelector('input:focus') || (el.querySelector('input[name=text]') || {}).value)) return;
      const p = D.post(el.dataset.id);
      if (!p) { el.remove(); return; }
      const tmp = document.createElement('div'); tmp.innerHTML = UT.postCard(p); el.replaceWith(tmp.firstElementChild);
    });
  };
  UT.updateThread = (force) => {
    const u = me(); const box = $('#msgs'); if (!u || !box || !UT.cur) return; const id = UT.cur.parts[1];
    const near = box.scrollHeight - box.scrollTop - box.clientHeight < 90;
    const playing = [...box.querySelectorAll('audio')].some((a) => !a.paused);
    if (!playing) box.innerHTML = UT.threadHTML(u.id, id);
    if (near || force) box.scrollTop = box.scrollHeight;
    D.markRead(u.id, id);
  };
  UT.refreshAny = () => {
    const v = UT.view; if (!v) return;
    if (v.thread) UT.updateThread(true); else if (v.refresh) UT.refresh(); else UT.refreshPosts();
    UT.updateBadges();
  };
  UT.updateBadges = () => {
    const u = me(); if (!u) return;
    const set = (k, n) => document.querySelectorAll(`[data-badge="${k}"]`).forEach((b) => { b.textContent = n; b.hidden = !n; });
    set('chat', D.unreadMsgs(u.id)); set('notif', D.unreadNotifs(u.id));
  };

  /* tempo real: mensagens/notificações novas chegam por BroadcastChannel (RNF07) */
  let snap = null;
  function detectNew() {
    const u = me(); if (!u) return; const cur = D.snapshot();
    if (snap && UT.prefs().toasts !== false) {
      const seenM = new Set(snap.msgs); const seenN = new Set(snap.notifs);
      D.thread && D.convs(u.id); // garante consistência
      const openId = UT.view && UT.view.thread ? UT.cur.parts[1] : null;
      cur.msgs.filter((i) => !seenM.has(i)).forEach((i) => {
        const m = D.thread(u.id, openId || '__').find((x) => x.id === i);
        if (m) return; // conversa aberta: já aparece na tela
        const all = D.convs(u.id).map((c) => c.last).find((x) => x && x.id === i);
        if (all && all.to === u.id && all.type !== 'system') UT.toast(`Nova mensagem de ${D.user(all.from).name}`, 'info');
      });
      cur.notifs.filter((i) => !seenN.has(i)).forEach((i) => {
        const n = D.notifs(u.id).find((x) => x.id === i); if (n) UT.toast(n.text, 'info');
      });
    }
    snap = cur;
  }
  UT.resetSnap = () => { snap = D.snapshot(); };

  UT.on('change', () => {
    const u = me();
    if (UT.session.get() && !u) { UT.session.clear(); UT.go('#/welcome'); return; }
    if (!u) return;
    detectNew(); UT.updateBadges(); UT.refreshAny();
  });
  UT.on('media', (id) => {
    const url = UT.Media.cache[id];
    document.querySelectorAll(`[data-mid="${id}"]`).forEach((el) => { if (el.getAttribute('src') !== url) el.setAttribute('src', url); });
  });
  UT.on('error', (m) => UT.toast(m, 'error'));

  (async function start() {
    applyPrefs();
    await UT.init();
    UT.resetSnap();
    window.addEventListener('hashchange', route);
    route();
  })();
})();
