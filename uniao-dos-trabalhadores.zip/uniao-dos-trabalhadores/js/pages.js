/* Páginas da aplicação. Cada função devolve { title, html, back?, nav?, after?, refresh?, bare?, hideNav? }. */
(function () {
  'use strict';
  const UT = window.UT; const { ic, esc, money } = UT; const D = UT.D;
  const me = () => D.user(UT.session.get());
  const P = (UT.pages = {});
  const cityOptions = (sel, allLabel) => {
    const set = new Set(Object.keys(UT.CITIES)); D.pros().forEach((p) => set.add(p.city)); const u = me(); if (u) set.add(u.city);
    return (allLabel ? `<option value="" ${!sel ? 'selected' : ''}>${allLabel}</option>` : '') + [...set].sort().map((c) => `<option ${c === sel ? 'selected' : ''}>${esc(c)}</option>`).join('');
  };
  const catOptions = (sel, all) => (all ? `<option value="">${all}</option>` : '') + UT.CATS.map((c) => `<option ${c === sel ? 'selected' : ''}>${esc(c)}</option>`).join('');
  const datalist = () => `<datalist id="cities">${Object.keys(UT.CITIES).map((c) => `<option value="${esc(c)}">`).join('')}</datalist>`;
  const pageHead = (t, s) => `<div class="page-head"><h2>${t}</h2>${s ? `<p class="muted">${s}</p>` : ''}</div>`;

  /* ============ autenticação ============ */
  P.welcome = () => ({
    bare: true, title: 'Bem-vindo',
    html: `<section class="auth welcome"><div class="hero" aria-hidden="true"><div class="blob"></div><div class="fc c1">${UT.icFill('star', 16)} <b>4,9</b> Eletricista</div><div class="fc c2">${ic('calendar', 16)} Hoje, 14h</div><div class="fc c3">${ic('chat', 16)} Chat</div><div class="fc c4">${ic('dollar', 16)} Faturamento</div>${UT.logo(92)}</div>
      <h1>Bem-vindo!</h1><p class="lead">Conecte-se com clientes e ofereça seus serviços de forma simples.</p>
      <div class="mode-hint"><span class="c">${ic('search', 16)} Contrate</span><span class="p">${ic('briefcase', 16)} Ofereça serviços</span></div>
      <a class="btn primary lg block" href="#/signup">Criar conta</a><p class="center small">Já tem uma conta? <a href="#/login"><b>Entrar</b></a></p></section>`
  });

  P.login = () => ({
    bare: true, title: 'Entrar',
    html: `<section class="auth"><a class="back-link" href="#/welcome">${ic('chevL')} Voltar</a>${UT.logo(48)}<h1>Entrar</h1><p class="muted">Acesse sua conta União dos Trabalhadores.</p>
      <form class="form" data-form="login" novalidate>
        <label>E-mail<span class="field">${ic('mail', 18)}<input name="email" type="email" autocomplete="email" required placeholder="voce@email.com"></span></label>
        <label>Senha<span class="field">${ic('lock', 18)}<input name="password" type="password" autocomplete="current-password" required placeholder="Sua senha"></span></label>
        <label class="check"><input type="checkbox" name="remember"><span>Manter conectado neste navegador</span></label>
        <p class="form-err" role="alert" id="form-err"></p>
        <button class="btn primary lg block">Entrar</button></form>
      <p class="center small">Não tem conta? <a href="#/signup"><b>Criar conta</b></a></p>
      <div class="demo-box"><b>Acesso de demonstração</b><p class="small muted">Contas fictícias para testar o protótipo (senha: <code>demo123</code>).</p>
        <div class="row gap wrap"><button class="btn tonal sm" data-act="demo-login" data-email="juliana@demo.com">${ic('user', 16)} Cliente: Juliana</button><button class="btn tonal green sm" data-act="demo-login" data-email="carlos@demo.com">${ic('briefcase', 16)} Profissional: Carlos</button></div></div></section>`
  });

  P.signup = () => ({
    bare: true, title: 'Criar conta',
    html: `<section class="auth"><a class="back-link" href="#/welcome">${ic('chevL')} Voltar</a>${UT.logo(48)}<h1>Criar conta</h1><p class="muted">Um único cadastro para contratar ou oferecer serviços.</p>
      <form class="form" data-form="signup" novalidate>
        <label>Nome completo<span class="field">${ic('user', 18)}<input name="name" autocomplete="name" required minlength="3" placeholder="Seu nome"></span></label>
        <label>E-mail<span class="field">${ic('mail', 18)}<input name="email" type="email" autocomplete="email" required placeholder="voce@email.com"></span></label>
        <label>Senha<span class="field">${ic('lock', 18)}<input name="password" type="password" autocomplete="new-password" required minlength="6" placeholder="Mínimo de 6 caracteres"></span></label>
        <label>Cidade<span class="field">${ic('pin', 18)}<input name="city" list="cities" required placeholder="Ex.: Bragança - PA"></span></label>${datalist()}
        <label class="check"><input type="checkbox" name="terms" required><span>Li e aceito os <a href="#/politicas" target="_blank" rel="noopener">termos e a política de privacidade</a></span></label>
        <p class="form-err" role="alert" id="form-err"></p>
        <button class="btn primary lg block">Criar conta</button></form></section>`
  });

  P.modo = () => {
    const u = me();
    return {
      bare: true, title: 'Escolha seu modo',
      html: `<section class="auth"><h1>Escolha seu modo</h1><p class="muted">Selecione como deseja utilizar o aplicativo. Você pode alternar entre os modos quando quiser, com a mesma conta.</p>
        <div class="mode-cards"><button class="mode-card client" data-act="choose-mode" data-mode="cliente"><span class="mc-ico">${ic('user', 28)}</span><span><b>Cliente</b><small>Quero contratar serviços</small></span></button>
        <button class="mode-card pro" data-act="choose-mode" data-mode="profissional"><span class="mc-ico">${ic('briefcase', 28)}</span><span><b>Profissional</b><small>Quero oferecer meus serviços</small></span></button></div>
        ${u && u.mode ? `<p class="center"><a href="#/inicio">Cancelar</a></p>` : ''}</section>`
    };
  };

  P.ativar = () => ({
    bare: true, title: 'Ativar perfil profissional',
    html: `<section class="auth"><a class="back-link" href="#/modo">${ic('chevL')} Voltar</a><h1>Perfil profissional</h1><p class="muted">Conte o que você faz. Você poderá editar tudo depois.</p>
      <form class="form" data-form="activate-pro" novalidate>
        <label>Profissão / categoria<select name="category" required>${catOptions('', 'Selecione…')}</select></label>
        <label>Descrição do seu trabalho<textarea name="description" rows="3" required maxlength="300" placeholder="Ex.: Eletricista com 10 anos de experiência…"></textarea></label>
        <fieldset class="fs"><legend>Primeiro serviço oferecido</legend>
          <label>Nome do serviço<input name="serviceName" required maxlength="60" placeholder="Ex.: Visita técnica"></label>
          <label>Preço (R$)<input name="price" type="number" min="0" step="0.01" inputmode="decimal" required placeholder="0,00"></label></fieldset>
        <p class="form-err" role="alert" id="form-err"></p><button class="btn primary lg block green">Ativar modo Profissional</button></form></section>`
  });

  /* ============ início ============ */
  const feedHTML = () => {
    const u = me(); const s = UT.state;
    const list = D.posts().filter((p) => {
      const a = D.user(p.authorId); if (!a || !a.pro || p.authorId === u.id) return false;
      if (s.feedCity && UT.norm(a.city) !== UT.norm(s.feedCity)) return false;
      if (s.feedCat && a.pro.category !== s.feedCat) return false;
      return true;
    });
    return list.length ? list.map((p) => UT.postCard(p)).join('') : UT.empty('image', 'Nenhuma publicação por aqui', 'Não encontramos publicações com esses filtros. Tente outra cidade ou categoria, ou busque profissionais pelo menu Buscar.', '<a class="btn tonal" href="#/buscar">Buscar profissionais</a>');
  };
  const featuredHTML = (city) => {
    const u = me();
    const list = D.pros().filter((p) => p.id !== u.id && (!city || p.city === city)).map((p) => ({ p, r: D.rating(p.id) })).filter((x) => x.r.n > 0).sort((a, b) => b.r.avg - a.r.avg || b.r.n - a.r.n).slice(0, 8);
    if (!list.length) return '';
    return `<section class="featured" aria-label="Profissionais mais bem avaliados"><h3 class="sec">Mais bem avaliados${city ? ` em ${esc(city.split(' - ')[0])}` : ''}</h3><div class="feat-row">${list.map(({ p, r }) => `<a class="feat" href="#/pro/${p.id}">${UT.avatar(p, 48)}<b>${esc(p.name.split(' ')[0])}</b><span class="muted small">${esc(p.pro.category)}</span><span class="feat-r">${UT.icFill('star', 14)} ${r.avg.toFixed(1).replace('.', ',')} <span class="muted">(${r.n})</span></span></a>`).join('')}</div></section>`;
  };
  const clientHome = () => {
    const u = me(); const s = UT.state; if (s.feedCity === null) s.feedCity = u.city;
    const cats = [...new Set(D.pros().map((p) => p.pro.category))].sort();
    return {
      title: 'Descobrir', nav: 'inicio',
      html: `<div class="page-head greet"><h2>Olá, ${esc(u.name.split(' ')[0])}!</h2><p class="muted">Profissionais e novidades perto de você.</p></div>
        ${featuredHTML(s.feedCity)}
        <div class="filters"><label class="select-chip">${ic('pin', 18)}<span class="sr">Cidade</span><select data-change="feed-city" aria-label="Cidade">${cityOptions(s.feedCity, 'Todas as cidades')}</select></label></div>
        <div class="chips" role="group" aria-label="Filtrar por categoria"><button class="chip ${!s.feedCat ? 'on' : ''}" data-act="feed-cat" data-cat="">Todas</button>${cats.map((c) => `<button class="chip ${s.feedCat === c ? 'on' : ''}" data-act="feed-cat" data-cat="${esc(c)}">${ic((UT.CAT_ICON || {})[c] || 'briefcase', 16)}${esc(c)}</button>`).join('')}</div>
        <div id="feed">${feedHTML()}</div>`
    };
  };

  const nextAppointment = (id) => {
    const now = Date.now();
    return D.ordersOfPro(id).filter((o) => o.status === 'aceito' && +new Date(`${o.date}T${o.time}:00`) >= now).sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))[0];
  };
  const draftHTML = () => UT.state.draftMedia.map((m, i) => `<div class="draft">${UT.mediaEl(m, 'd-item')}<button type="button" class="icon-btn sm x" data-act="draft-remove" data-i="${i}" aria-label="Remover mídia">${ic('x', 16)}</button></div>`).join('');
  UT.draftHTML = draftHTML;
  const proHome = () => {
    const u = me(); const pend = D.ordersOfPro(u.id).filter((o) => o.status === 'pendente').length;
    const nx = nextAppointment(u.id); const fin = D.finance(u.id, 'mes', 0);
    const mine = D.posts().filter((p) => p.authorId === u.id);
    return {
      title: 'Início', nav: 'inicio',
      html: `<div class="page-head"><h2>Olá, ${esc(u.name.split(' ')[0])}!</h2><p class="muted">Resumo do seu trabalho</p></div>
        <div class="stats">
          <a class="stat" href="#/agenda/pedidos"><span class="stat-ico amber">${ic('clipboard', 20)}</span><b>${pend}</b><small>Pedido${pend === 1 ? '' : 's'} pendente${pend === 1 ? '' : 's'}</small></a>
          <a class="stat" href="#/agenda"><span class="stat-ico blue">${ic('calendar', 20)}</span><b class="sm">${nx ? `${UT.fmtDateShort(nx.date)} · ${nx.time}` : '—'}</b><small>${nx ? 'Próximo: ' + esc(nx.serviceName) : 'Próximo atendimento: nenhum agendado'}</small></a>
          <a class="stat" href="#/agenda/financeiro"><span class="stat-ico green">${ic('dollar', 20)}</span><b class="sm">${money(fin.total)}</b><small>Faturamento do mês (estimativa)</small></a></div>
        <form class="card composer-post" data-form="new-post"><h3>Divulgar um trabalho</h3>
          <label class="sr" for="post-text">Legenda da publicação</label><textarea id="post-text" name="text" rows="3" maxlength="800" placeholder="Descreva o serviço realizado, novidades ou horários disponíveis…"></textarea>
          <div id="draft" class="draft-media">${draftHTML()}</div>
          <div class="row between"><label class="btn ghost sm file-btn" for="post-files">${ic('image', 18)} Foto / vídeo</label><input id="post-files" type="file" accept="image/*,video/*" multiple hidden data-change="post-files"><button class="btn primary green">Publicar</button></div></form>
        <h3 class="sec">Minhas publicações</h3>
        ${mine.length ? mine.map((p) => UT.postCard(p)).join('') : UT.empty('image', 'Você ainda não publicou nada', 'Publique fotos e vídeos dos seus trabalhos para ganhar visibilidade na região.')}`
    };
  };
  P.inicio = () => (me().mode === 'profissional' ? proHome() : clientHome());

  /* ============ buscar ============ */
  const proCard = (p) => {
    const u = me(); const fav = D.favs(u.id).includes(p.id); const min = p.pro.services.length ? Math.min(...p.pro.services.map((s) => s.price)) : null;
    return `<article class="card pro-card"><a class="pro-link" href="#/pro/${p.id}">${UT.avatar(p, 58)}<span class="pro-info"><b>${esc(p.name)}</b><span class="muted small">${esc(p.pro.category)}</span><span class="muted small">${ic('pin', 13)} ${esc(p.city)}</span>${UT.ratingLine(p.id)}</span></a>
      <div class="pro-foot"><span class="small muted">${min != null ? `a partir de <b>${money(min)}</b>` : ''}</span><span class="row gap"><button class="icon-btn ${fav ? 'fav on' : 'fav'}" data-act="fav" data-id="${p.id}" aria-pressed="${fav}" aria-label="${fav ? 'Remover dos favoritos' : 'Favoritar'}">${fav ? UT.icFill('heart', 20) : ic('heart', 20)}</button><a class="btn tonal sm" href="#/pro/${p.id}">Ver perfil</a></span></div></article>`;
  };
  const resultsHTML = () => {
    const u = me(); const s = UT.state.search; const q = UT.norm(s.q);
    let list = D.pros().filter((p) => p.id !== u.id);
    if (s.city) list = list.filter((p) => UT.norm(p.city) === UT.norm(s.city));
    if (s.cat) list = list.filter((p) => p.pro.category === s.cat);
    if (q) list = list.filter((p) => UT.norm([p.name, p.pro.category, p.pro.description, ...p.pro.services.map((x) => x.name)].join(' ')).includes(q));
    list.sort((a, b) => (s.sort === 'nome' ? a.name.localeCompare(b.name) : (D.rating(b.id).avg - D.rating(a.id).avg) || (D.rating(b.id).n - D.rating(a.id).n)));
    return { n: list.length, html: list.length ? list.map(proCard).join('') : UT.empty('search', 'Nenhum profissional encontrado', 'Tente outra palavra, categoria ou selecione "Todas as cidades".') };
  };
  UT.resultsHTML = resultsHTML;
  P.buscar = () => {
    const u = me(); const s = UT.state.search; if (s.city === null) s.city = u.city; const r = resultsHTML();
    return {
      title: 'Buscar', nav: 'buscar',
      html: `${pageHead('Buscar profissionais', 'Encontre quem atende na sua cidade')}
        <div class="search-box">${ic('search', 20)}<label class="sr" for="q">Buscar</label><input id="q" type="search" data-input="search-q" placeholder="Nome, serviço ou categoria" value="${esc(s.q)}" autocomplete="off"></div>
        <div class="filter-row"><label class="sel">Cidade<select data-change="search-city">${cityOptions(s.city, 'Todas as cidades')}</select></label><label class="sel">Categoria<select data-change="search-cat">${catOptions(s.cat, 'Todas')}</select></label><label class="sel">Ordenar<select data-change="search-sort"><option value="rating" ${s.sort === 'rating' ? 'selected' : ''}>Melhor avaliação</option><option value="nome" ${s.sort === 'nome' ? 'selected' : ''}>Nome (A–Z)</option></select></label></div>
        <button class="btn ghost sm" data-act="use-location">${ic('target', 16)} Usar minha localização</button>
        <p class="muted small" id="res-count" aria-live="polite">${r.n} profissional${r.n === 1 ? '' : 'is'} encontrado${r.n === 1 ? '' : 's'}</p><div id="results">${r.html}</div>`
    };
  };

  /* ============ perfil público do profissional ============ */
  P.pro = (id) => {
    const p = D.user(id); const u = me();
    if (!p || !p.pro) return { title: 'Perfil', back: '#/buscar', html: UT.empty('user', 'Perfil não encontrado', 'Este profissional não está mais disponível.') };
    const own = p.id === u.id; const fav = D.favs(u.id).includes(p.id); const rv = D.reviewsOf(p.id); const posts = D.posts().filter((x) => x.authorId === p.id);
    const r = D.rating(p.id);
    return {
      title: p.name, back: '#/buscar', nav: u.mode === 'profissional' ? 'inicio' : 'buscar',
      html: `<section class="card pro-head"><div class="cover"></div>${UT.avatar(p, 92)}<h2>${esc(p.name)}</h2><span class="mode-label pro">Profissional</span>
        <p class="muted">${esc(p.pro.category)} · ${ic('pin', 14)} ${esc(p.city)}</p>
        <div class="rate-big">${r.n ? `${UT.stars(r.avg, 20)}<b>${r.avg.toFixed(1).replace('.', ',')}</b><span class="muted">${r.n} avaliaç${r.n > 1 ? 'ões' : 'ão'}</span>` : '<span class="muted">Ainda sem avaliações</span>'}</div>
        ${own ? '<a class="btn tonal green" href="#/editar-perfil">Editar meu perfil</a>' : `<div class="row gap center wrap"><button class="btn primary" data-act="request" data-id="${p.id}">${ic('clipboard', 18)} Solicitar serviço</button><a class="btn ghost" href="#/chat/${p.id}">${ic('chat', 18)} Conversar</a><button class="icon-btn fav ${fav ? 'on' : ''}" data-act="fav" data-id="${p.id}" aria-pressed="${fav}" aria-label="${fav ? 'Remover dos favoritos' : 'Favoritar'}">${fav ? UT.icFill('heart', 22) : ic('heart', 22)}</button></div>`}</section>
        <section class="card"><h3>Sobre</h3><p>${UT.nl2br(p.pro.description)}</p></section>
        <section class="card"><h3>Serviços e preços</h3><ul class="svc-list">${p.pro.services.map((s) => `<li><span>${esc(s.name)}</span><b>${money(s.price)}</b></li>`).join('') || '<li class="muted">Nenhum serviço cadastrado.</li>'}</ul></section>
        <h3 class="sec">Publicações</h3>${posts.length ? posts.map((x) => UT.postCard(x)).join('') : '<p class="muted">Nenhuma publicação ainda.</p>'}
        <h3 class="sec" id="avaliacoes">Avaliações de clientes</h3>
        ${rv.length ? rv.map((x) => { const c = D.user(x.clientId); const o = D.order(x.orderId); return `<article class="card review"><div class="rv-h">${UT.avatar(c, 38)}<span><b>${esc(c ? c.name : 'Usuário removido')}</b><small class="muted">${UT.timeAgo(x.at)}${o ? ' · ' + esc(o.serviceName) : ''}</small></span>${UT.stars(x.stars, 15)}</div>${x.comment ? `<p>${UT.nl2br(x.comment)}</p>` : ''}</article>`; }).join('') : '<p class="muted">Este profissional ainda não recebeu avaliações.</p>'}`
    };
  };

  P.post = (id) => {
    const p = D.post(id);
    return { title: 'Publicação', back: '#/inicio', nav: 'inicio', html: p ? UT.postCard(p) : UT.empty('image', 'Publicação não encontrada', 'Ela pode ter sido removida pelo autor.') };
  };

  /* ============ chat ============ */
  const previewOf = (m, meId) => {
    const pre = m.from === meId ? 'Você: ' : '';
    if (m.type === 'audio') return pre + '🎤 Mensagem de voz';
    if (m.type === 'order') return pre + '📋 Pedido de serviço';
    if (m.type === 'call') return '📞 Chamada de voz';
    if (m.type === 'post') return pre + '🔗 Publicação compartilhada';
    if (m.type === 'system') return m.text;
    return pre + m.text;
  };
  P.chat = () => {
    const u = me(); const cs = D.convs(u.id);
    return {
      title: 'Chat', nav: 'chat',
      html: `${pageHead('Conversas', u.mode === 'cliente' ? 'Fale diretamente com os profissionais' : 'Converse com seus clientes')}
        ${cs.length ? `<ul class="conv-list">${cs.map((c) => { const o = D.user(c.other); return `<li><a class="conv ${c.unread ? 'unread' : ''}" href="#/chat/${o.id}">${UT.avatar(o, 50)}<span class="conv-b"><b>${esc(o.name)}</b><span class="conv-last">${esc(previewOf(c.last, u.id))}</span></span><span class="conv-r"><small>${UT.clock(c.last.at)}</small>${c.unread ? `<span class="badge">${c.unread}</span>` : ''}</span></a></li>`; }).join('')}</ul>`
          : UT.empty('chat', 'Nenhuma conversa ainda', u.mode === 'cliente' ? 'Abra o perfil de um profissional e toque em "Conversar" para começar.' : 'Quando um cliente entrar em contato ou solicitar um serviço, a conversa aparecerá aqui.', u.mode === 'cliente' ? '<a class="btn tonal" href="#/buscar">Buscar profissionais</a>' : '')}`,
      refresh: true
    };
  };

  const msgHTML = (m, meId) => {
    const mine = m.from === meId;
    if (m.type === 'system') return `<div class="sys">${esc(m.text)}</div>`;
    if (m.type === 'call') {
      const t = m.status === 'atendida' ? `Chamada de voz · ${UT.dur(m.duration || 0)}` : m.status === 'perdida' ? (mine ? 'Chamada não atendida' : 'Chamada perdida') : 'Chamada recusada';
      return `<div class="sys call ${m.status === 'atendida' ? '' : 'miss'}">${ic(m.status === 'atendida' ? 'phone' : 'phoneoff', 15)} ${t} <span>${UT.clock(m.at)}</span></div>`;
    }
    let body = '';
    if (m.type === 'text') body = `<p>${UT.nl2br(m.text)}</p>`;
    else if (m.type === 'audio') body = `<div class="audio"><audio controls preload="metadata" data-mid="${m.mediaId}" ${UT.Media.url(m.mediaId) ? `src="${UT.Media.url(m.mediaId)}"` : ''} aria-label="Mensagem de voz"></audio><small>${UT.dur(m.duration || 0)}</small></div>`;
    else if (m.type === 'order') { const o = D.order(m.orderId); body = o ? UT.orderCard(o, meId, { inChat: true }) : '<p class="muted">Pedido removido.</p>'; }
    else if (m.type === 'post') {
      const p = D.post(m.postId); const a = p && D.user(p.authorId);
      body = p ? `<a class="share-card" href="#/post/${p.id}">${p.media[0] ? UT.mediaEl(p.media[0], 'sc-img') : ''}<span><b>${esc(a ? a.name : '')}</b><small>${esc((p.text || 'Publicação').slice(0, 80))}</small></span></a>` : '<p class="muted">Publicação removida.</p>';
    }
    const tick = mine && m.type !== 'order' ? `<span class="tick ${m.read ? 'read' : ''}" aria-label="${m.read ? 'Lida' : 'Enviada'}">${ic('check', 13)}${m.read ? ic('check', 13) : ''}</span>` : '';
    return `<div class="msg ${mine ? 'mine' : 'theirs'} t-${m.type}">${body}<span class="meta">${UT.clock(m.at)} ${tick}</span></div>`;
  };
  UT.threadHTML = (meId, otherId) => {
    const th = D.thread(meId, otherId); let last = '';
    if (!th.length) return '<p class="muted center pad">Nenhuma mensagem ainda. Diga olá! 👋</p>';
    return th.map((m) => {
      const day = new Date(m.at).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
      const sep = day !== last ? `<div class="day-sep"><span>${day}</span></div>` : ''; last = day;
      return sep + msgHTML(m, meId);
    }).join('');
  };
  P.thread = (id) => {
    const u = me(); const o = D.user(id);
    if (!o || o.id === u.id) return { title: 'Chat', back: '#/chat', html: UT.empty('chat', 'Conversa não encontrada', 'Este usuário não está disponível.') };
    return {
      title: o.name, back: '#/chat', nav: 'chat', hideNav: true, thread: true,
      html: `<div class="thread"><div class="thread-h">${UT.avatar(o, 44)}<span><b>${esc(o.name)}</b><small class="muted">${o.pro ? esc(o.pro.category) + ' · ' : ''}${esc(o.city)}</small></span><span class="spacer"></span>
          ${o.pro ? `<a class="icon-btn" href="#/pro/${o.id}" aria-label="Ver perfil">${ic('user', 20)}</a>` : ''}<button class="icon-btn accent" data-act="call" data-id="${o.id}" aria-label="Iniciar chamada de voz">${ic('phone', 20)}</button></div>
        <div id="msgs" class="msgs" aria-live="polite">${UT.threadHTML(u.id, o.id)}</div>
        <form class="composer" data-form="send-msg" data-to="${o.id}" autocomplete="off"><button type="button" class="icon-btn" data-act="rec-start" aria-label="Gravar mensagem de voz">${ic('mic', 22)}</button><label class="sr" for="msg-text">Mensagem</label><input id="msg-text" name="text" placeholder="Digite uma mensagem" maxlength="1000"><button class="icon-btn accent send" aria-label="Enviar mensagem">${ic('send', 20)}</button></form>
        <div class="recbar" id="recbar" hidden><span class="rec-dot"></span><b id="rec-time">00:00</b><span class="muted small">Gravando…</span><span class="spacer"></span><button class="btn ghost sm" data-act="rec-cancel">Cancelar</button><button class="btn primary sm" data-act="rec-send">${ic('send', 16)} Enviar</button></div></div>`,
      after: () => { D.markRead(u.id, o.id); const m = document.getElementById('msgs'); if (m) m.scrollTop = m.scrollHeight; }
    };
  };

  /* ============ pedidos do cliente ============ */
  const FILTERS = [['todos', 'Todos'], ['pendente', 'Pendentes'], ['aceito', 'Agendados'], ['concluido', 'Concluídos'], ['encerrado', 'Cancelados']];
  const matchF = (o, f) => f === 'todos' || o.status === f || (f === 'encerrado' && (o.status === 'cancelado' || o.status === 'recusado'));
  const ordersList = (list, viewerId) => {
    const f = UT.state.orderFilter; const l = list.filter((o) => matchF(o, f)).sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
    return l.length ? l.map((o) => UT.orderCard(o, viewerId)).join('') : UT.empty('clipboard', 'Nenhum pedido aqui', 'Os pedidos com este filtro aparecerão nesta lista.');
  };
  const filterChips = () => `<div class="chips" role="group" aria-label="Filtrar pedidos">${FILTERS.map(([k, l]) => `<button class="chip ${UT.state.orderFilter === k ? 'on' : ''}" data-act="order-filter" data-f="${k}">${l}</button>`).join('')}</div>`;
  P.pedidos = () => {
    const u = me();
    return { title: 'Meus pedidos', back: '#/perfil', nav: 'perfil', refresh: true, html: `${filterChips()}${ordersList(D.ordersOfClient(u.id), u.id)}` };
  };

  /* ============ agenda do profissional ============ */
  const tabs = (cur) => {
    const u = me(); const pend = D.ordersOfPro(u.id).filter((o) => o.status === 'pendente').length;
    return `<div class="tabs" role="tablist">${[['', 'Calendário'], ['pedidos', 'Pedidos'], ['financeiro', 'Financeiro']].map(([k, l]) => `<a role="tab" aria-selected="${cur === k}" class="${cur === k ? 'on' : ''}" href="#/agenda${k ? '/' + k : ''}">${l}${k === 'pedidos' && pend ? ` <span class="badge">${pend}</span>` : ''}</a>`).join('')}</div>`;
  };
  const calendarHTML = () => {
    const u = me(); const A = UT.state.agenda; const now = new Date();
    if (!A.month) A.month = { y: now.getFullYear(), m: now.getMonth() };
    if (!A.day) A.day = UT.todayStr();
    const { y, m } = A.month; const first = new Date(y, m, 1); const n = new Date(y, m + 1, 0).getDate();
    const ords = D.ordersOfPro(u.id).filter((o) => ['pendente', 'aceito', 'concluido'].includes(o.status));
    const byDay = {}; ords.forEach((o) => { (byDay[o.date] = byDay[o.date] || []).push(o); });
    let cells = ['D', 'S', 'T', 'Q', 'Q', 'S', 'S'].map((d, i) => `<span class="dow" aria-hidden="true">${d}</span>`).join('');
    for (let i = 0; i < first.getDay(); i++) cells += '<span></span>';
    for (let d = 1; d <= n; d++) {
      const ds = UT.ymd(new Date(y, m, d)); const l = byDay[ds] || [];
      const blocked = u.pro.avail.blocked.includes(ds);
      const dots = [l.some((o) => o.status === 'pendente') ? 'amber' : '', l.some((o) => o.status === 'aceito') ? 'blue' : '', l.some((o) => o.status === 'concluido') ? 'green' : ''].filter(Boolean).map((c) => `<i class="${c}"></i>`).join('');
      cells += `<button class="day ${ds === A.day ? 'sel' : ''} ${ds === UT.todayStr() ? 'today' : ''} ${blocked ? 'blocked' : ''}" data-act="cal-day" data-date="${ds}" aria-label="${UT.fmtDateLong(ds)}${l.length ? ', ' + l.length + ' compromisso(s)' : ''}${blocked ? ', dia bloqueado' : ''}" aria-pressed="${ds === A.day}">${d}<span class="dots">${dots}</span></button>`;
    }
    const dayOrders = (byDay[A.day] || []).sort((a, b) => a.time.localeCompare(b.time));
    const blockedDay = u.pro.avail.blocked.includes(A.day);
    const cfg = u.pro.avail.weekly;
    return `<div class="card cal"><div class="cal-h"><button class="icon-btn" data-act="cal-prev" aria-label="Mês anterior">${ic('chevL')}</button><h3>${new Date(y, m, 1).toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' })}</h3><button class="icon-btn" data-act="cal-next" aria-label="Próximo mês">${ic('chevR')}</button></div>
      <div class="cal-grid">${cells}</div><div class="legend"><span><i class="amber"></i>Pendente</span><span><i class="blue"></i>Agendado</span><span><i class="green"></i>Concluído</span><span><i class="x"></i>Bloqueado</span></div></div>
      <div class="card"><div class="row between wrap gap"><h3>${UT.fmtDateLong(A.day)}</h3>${blockedDay ? '<span class="pill gray">Dia bloqueado</span>' : ''}</div>
        ${dayOrders.length ? dayOrders.map((o) => UT.orderCard(o, u.id)).join('') : '<p class="muted">Nenhum compromisso neste dia.</p>'}
        <div class="row gap wrap"><button class="btn primary green sm" data-act="new-manual">${ic('plus', 16)} Novo compromisso</button><button class="btn ghost sm" data-act="toggle-block">${ic('ban', 16)} ${blockedDay ? 'Desbloquear dia' : 'Bloquear dia'}</button></div></div>
      <form class="card avail" data-form="avail"><h3>Horários de atendimento</h3><p class="muted small">Os clientes só conseguem solicitar horários cheios (de 1 em 1 hora) dentro destes períodos.</p>
        ${[0, 1, 2, 3, 4, 5, 6].map((i) => `<div class="av-row"><label class="switch"><input type="checkbox" name="on${i}" ${cfg[i].on ? 'checked' : ''}><span class="knob"></span><span class="wd">${UT.WEEKDAYS[i]}</span></label><span class="av-times"><label class="sr" for="s${i}">Início ${UT.WEEKDAYS[i]}</label><input id="s${i}" type="time" name="start${i}" value="${cfg[i].start}" required><span aria-hidden="true">–</span><label class="sr" for="e${i}">Fim ${UT.WEEKDAYS[i]}</label><input id="e${i}" type="time" name="end${i}" value="${cfg[i].end}" required></span></div>`).join('')}
        <button class="btn primary green">Salvar horários</button></form>`;
  };
  const barChart = (f, period) => {
    const W = 640; const H = 230; const L = 8; const B = 28; const T = 12; const max = Math.max(...f.buckets.map((b) => b.value), 1);
    const nice = (() => { const p = Math.pow(10, Math.floor(Math.log10(max))); const k = max / p; return (k <= 1 ? 1 : k <= 2 ? 2 : k <= 5 ? 5 : 10) * p; })();
    const bw = (W - L * 2) / f.buckets.length; const ch = H - B - T;
    const grid = [0, 0.5, 1].map((g) => `<line x1="${L}" x2="${W - L}" y1="${T + ch - ch * g}" y2="${T + ch - ch * g}" class="gl"/><text x="${L + 2}" y="${T + ch - ch * g - 4}" class="gt">${g ? money(nice * g).replace(',00', '') : ''}</text>`).join('');
    const bars = f.buckets.map((b, i) => {
      const h = (b.value / nice) * ch; const x = L + i * bw + bw * 0.14; const w = bw * 0.72;
      const showL = period !== 'mes' || i === 0 || (i + 1) % 5 === 0;
      return `<g><title>${b.label}: ${money(b.value)} (${b.count} serviço${b.count === 1 ? '' : 's'})</title><rect x="${x}" y="${T + ch - h}" width="${w}" height="${Math.max(h, b.value ? 2 : 0)}" rx="${Math.min(5, w / 3)}" class="bar"/>${showL ? `<text x="${x + w / 2}" y="${H - 8}" class="bt" text-anchor="middle">${b.label}</text>` : ''}</g>`;
    }).join('');
    return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Gráfico de faturamento por ${period === 'semana' ? 'dia da semana' : period === 'mes' ? 'dia do mês' : 'mês'}">${grid}${bars}</svg>`;
  };
  const financeHTML = () => {
    const u = me(); const F = UT.state.fin; const f = D.finance(u.id, F.period, F.offset);
    const seg = [['semana', 'Semanal'], ['mes', 'Mensal'], ['ano', 'Anual']].map(([k, l]) => `<button class="${F.period === k ? 'on' : ''}" data-act="fin-period" data-p="${k}" aria-pressed="${F.period === k}">${l}</button>`).join('');
    return `<div class="seg" role="group" aria-label="Período do relatório">${seg}</div>
      <div class="period-nav"><button class="icon-btn" data-act="fin-prev" aria-label="Período anterior">${ic('chevL')}</button><b>${esc(f.label)}</b><button class="icon-btn" data-act="fin-next" aria-label="Próximo período" ${F.offset >= 0 ? 'disabled' : ''}>${ic('chevR')}</button></div>
      <div class="stats three"><div class="stat static"><span class="stat-ico green">${ic('dollar', 20)}</span><b class="sm">${money(f.total)}</b><small>Faturamento (estimativa)</small></div><div class="stat static"><span class="stat-ico blue">${ic('check', 20)}</span><b>${f.count}</b><small>Serviços concluídos</small></div><div class="stat static"><span class="stat-ico amber">${ic('trend', 20)}</span><b class="sm">${money(f.avg)}</b><small>Valor médio</small></div></div>
      <div class="card"><h3>Faturamento por ${F.period === 'semana' ? 'dia' : F.period === 'mes' ? 'dia do mês' : 'mês'}</h3>${barChart(f, F.period)}</div>
      <div class="card"><h3>Por serviço</h3>${f.byService.length ? `<ul class="svc-list">${f.byService.map((s) => `<li><span>${esc(s.name)} <small class="muted">× ${s.count}</small></span><b>${money(s.total)}</b></li>`).join('')}</ul>` : '<p class="muted">Nenhum serviço concluído neste período.</p>'}</div>
      <div class="card"><h3>Serviços concluídos</h3>${f.list.length ? `<ul class="svc-list">${f.list.map((o) => { const c = o.clientId ? D.user(o.clientId) : null; return `<li><span>${esc(o.serviceName)}<small class="muted block">${esc(c ? c.name : o.clientName || 'Cliente externo')} · ${UT.fmtDate(UT.ymd(new Date(o.completedAt)))}</small></span><b>${money(o.finalValue)}</b></li>`; }).join('')}</ul>` : '<p class="muted">Nada por aqui ainda.</p>'}</div>
      <p class="muted small note">${ic('info', 14)} Valores estimados: somam os montantes informados pelo profissional ao concluir cada serviço. Não representam movimentação bancária.</p>`;
  };
  UT.calendarHTML = calendarHTML; UT.financeHTML = financeHTML;
  P.agenda = (sub) => {
    const u = me();
    if (sub === 'pedidos') {
      return { title: 'Agenda', nav: 'agenda', refresh: true, html: `${tabs('pedidos')}${filterChips()}${ordersList(D.ordersOfPro(u.id), u.id)}` };
    }
    if (sub === 'financeiro') return { title: 'Agenda', nav: 'agenda', refresh: true, html: `${tabs('financeiro')}<div id="fin">${financeHTML()}</div>` };
    return { title: 'Agenda', nav: 'agenda', refresh: true, html: `${tabs('')}<div id="cal">${calendarHTML()}</div>` };
  };

  /* ============ perfil e menus ============ */
  const menuItem = (href, icon, label, extra = '') => `<a class="menu-item" href="${href}">${ic(icon, 20)}<span>${label}</span>${extra}${ic('chevR', 18, 'chev')}</a>`;
  P.perfil = () => {
    const u = me(); const isPro = u.mode === 'profissional'; const nN = D.unreadNotifs(u.id);
    const items = isPro
      ? menuItem('#/editar-perfil', 'user', 'Meu perfil') + menuItem('#/servicos', 'briefcase', 'Serviços') + menuItem('#/publicacoes', 'image', 'Publicações') + menuItem('#/agenda', 'calendar', 'Agenda') + menuItem('#/notificacoes', 'bell', 'Notificações', nN ? `<span class="badge">${nN}</span>` : '') + menuItem('#/politicas', 'file', 'Políticas') + menuItem('#/config', 'settings', 'Configurações') + menuItem('#/ajuda', 'help', 'Ajuda')
      : menuItem('#/editar-perfil', 'user', 'Meu perfil') + menuItem('#/notificacoes', 'bell', 'Notificações', nN ? `<span class="badge">${nN}</span>` : '') + menuItem('#/favoritos', 'heart', 'Favoritos') + menuItem('#/pedidos', 'clipboard', 'Meus pedidos') + menuItem('#/config', 'settings', 'Configurações') + menuItem('#/ajuda', 'help', 'Ajuda');
    return {
      title: 'Perfil', nav: 'perfil',
      html: `<section class="profile-top">${UT.avatar(u, 92)}<h2>${esc(u.name)}</h2><span class="mode-label ${isPro ? 'pro' : 'client'}" id="mode-label">${UT.modeLabel(u.mode)}</span><p class="muted small">${ic('pin', 13)} ${esc(u.city)} · ${esc(u.email)}</p>
        <button class="btn tonal ${isPro ? '' : 'green'} sm" data-act="swap-mode">${ic('swap', 16)} Alternar para modo ${isPro ? 'Cliente' : 'Profissional'}</button></section>
        <nav class="menu card" aria-label="Menu do perfil">${items}<button class="menu-item danger" data-act="logout">${ic('logout', 20)}<span>Sair</span></button></nav>`
    };
  };

  P.editar = () => {
    const u = me();
    return {
      title: 'Editar perfil', back: '#/perfil', nav: 'perfil',
      html: `<form class="form card" data-form="edit-profile" novalidate>
        <div class="avatar-edit">${UT.avatar(u, 84)}<label class="btn tonal sm file-btn" for="avatar-file">${ic('camera', 16)} Alterar foto</label><input id="avatar-file" type="file" accept="image/*" hidden data-change="avatar"></div>
        <label>Nome<input name="name" value="${esc(u.name)}" required minlength="3"></label>
        <label>Cidade<input name="city" list="cities" value="${esc(u.city)}" required></label>${datalist()}
        ${u.pro ? `<fieldset class="fs"><legend>Perfil profissional</legend><label>Categoria<select name="category">${catOptions(u.pro.category)}</select></label><label>Descrição<textarea name="description" rows="4" maxlength="300" required>${esc(u.pro.description)}</textarea></label></fieldset>` : ''}
        <p class="form-err" role="alert" id="form-err"></p><button class="btn primary lg block ${u.mode === 'profissional' ? 'green' : ''}">Salvar</button></form>`
    };
  };

  P.servicos = () => {
    const u = me();
    return {
      title: 'Serviços', back: '#/perfil', nav: 'perfil', refresh: true,
      html: `<div class="row between"><p class="muted">Serviços que clientes podem solicitar no seu perfil.</p></div>
        <div class="card"><ul class="svc-list edit">${u.pro.services.map((s) => `<li><span>${esc(s.name)}<small class="block"><b>${money(s.price)}</b></small></span><span class="row gap"><button class="icon-btn" data-act="svc-edit" data-id="${s.id}" aria-label="Editar ${esc(s.name)}">${ic('edit', 18)}</button><button class="icon-btn" data-act="svc-del" data-id="${s.id}" aria-label="Excluir ${esc(s.name)}">${ic('trash', 18)}</button></span></li>`).join('') || '<li class="muted">Nenhum serviço cadastrado.</li>'}</ul></div>
        <button class="btn primary green" data-act="svc-new">${ic('plus', 18)} Adicionar serviço</button>`
    };
  };

  P.publicacoes = () => {
    const u = me(); const mine = D.posts().filter((p) => p.authorId === u.id);
    return { title: 'Publicações', back: '#/perfil', nav: 'perfil', html: `<a class="btn primary green" href="#/inicio">${ic('plus', 18)} Nova publicação</a><h3 class="sec">Gerenciar publicações (${mine.length})</h3>${mine.length ? mine.map((p) => UT.postCard(p)).join('') : UT.empty('image', 'Nenhuma publicação', 'Use "Nova publicação" para divulgar seu trabalho.')}` };
  };

  P.notificacoes = () => {
    const u = me(); const l = D.notifs(u.id);
    return {
      title: 'Notificações', back: '#/perfil', nav: 'perfil', refresh: true,
      html: l.length ? `<ul class="notif-list">${l.map((n) => `<li><a class="notif ${n.read ? '' : 'new'}" href="${esc(n.link || '#/inicio')}"><span class="n-ico">${ic(n.icon || 'bell', 18)}</span><span class="n-b">${esc(n.text)}<small class="muted block">${UT.timeAgo(n.at)}</small></span></a></li>`).join('')}</ul>` : UT.empty('bell', 'Sem notificações', 'Avisos sobre pedidos, avaliações e interações aparecerão aqui.'),
      after: () => setTimeout(() => { if (D.unreadNotifs(u.id)) { D.readNotifs(u.id); UT.updateBadges(); } }, 1200)
    };
  };

  P.favoritos = () => {
    const u = me(); const l = D.favs(u.id).map((i) => D.user(i)).filter((x) => x && x.pro);
    return { title: 'Favoritos', back: '#/perfil', nav: 'perfil', html: l.length ? l.map(proCard).join('') : UT.empty('heart', 'Nenhum favorito', 'Toque no coração no perfil de um profissional para guardá-lo aqui.', '<a class="btn tonal" href="#/buscar">Buscar profissionais</a>') };
  };

  P.politicas = () => ({
    title: 'Políticas', back: me() ? '#/perfil' : '#/signup', nav: 'perfil',
    html: `<article class="card prose"><p class="notice">${ic('info', 16)} Texto-modelo de demonstração. O artigo do projeto não define as políticas da plataforma; este conteúdo deve ser substituído por termos revisados antes de qualquer uso real.</p>
      <h3>Uso da plataforma</h3><p>A União dos Trabalhadores conecta clientes e profissionais autônomos. A plataforma não é parte dos contratos firmados entre eles e não garante a execução ou o resultado dos serviços.</p>
      <h3>Conteúdo publicado</h3><p>Cada usuário é responsável por fotos, vídeos, legendas, comentários e avaliações que publicar. Conteúdo ofensivo ou enganoso pode ser removido.</p>
      <h3>Avaliações</h3><p>Somente clientes que tiveram um serviço concluído com o profissional podem avaliá-lo, uma vez por serviço, com nota de 1 a 5 estrelas e comentário opcional.</p>
      <h3>Privacidade e dados</h3><p>Neste protótipo, todos os dados ficam armazenados apenas no navegador do usuário. Em uma versão com servidor, será necessário definir coleta, finalidade, retenção e direitos do titular, conforme a LGPD.</p>
      <h3>Cancelamentos</h3><p>Clientes e profissionais podem cancelar pedidos pendentes ou agendados pelo aplicativo; o outro lado é notificado.</p></article>`
  });

  P.config = () => {
    const u = me(); const pf = UT.prefs();
    return {
      title: 'Configurações', back: '#/perfil', nav: 'perfil',
      html: `<section class="card"><h3>Aparência</h3>
        <div class="seg" role="radiogroup" aria-label="Tema">${[['auto', 'Automático'], ['light', 'Claro'], ['dark', 'Escuro']].map(([v, l]) => `<label><input type="radio" name="theme" value="${v}" data-change="theme" ${(pf.theme || 'auto') === v ? 'checked' : ''}><span>${l}</span></label>`).join('')}</div>
        <p class="muted small">Automático segue o tema do aparelho.</p></section>
        <section class="card"><h3>Preferências</h3>
        <label class="switch row-switch"><input type="checkbox" data-change="pref" data-k="toasts" ${pf.toasts !== false ? 'checked' : ''}><span class="knob"></span><span>Avisos em tempo real (mensagens e notificações)</span></label>
        <label class="switch row-switch"><input type="checkbox" data-change="pref" data-k="large" ${pf.large ? 'checked' : ''}><span class="knob"></span><span>Texto maior</span></label>
        <label class="switch row-switch"><input type="checkbox" data-change="pref" data-k="contrast" ${pf.contrast ? 'checked' : ''}><span class="knob"></span><span>Alto contraste</span></label></section>
        <section class="card"><h3>Dados do protótipo</h3><p class="muted small">Os dados ficam somente neste navegador. ${D.meta().demo ? 'Atualmente o aplicativo contém <b>dados fictícios de demonstração</b>.' : 'Os dados atuais foram criados por você.'}</p>
          <div class="stack"><button class="btn ghost" data-act="reset-demo">Restaurar dados de demonstração</button><button class="btn ghost danger-t" data-act="wipe">Apagar todos os dados (começar vazio)</button><button class="btn ghost danger-t" data-act="del-account">Excluir minha conta</button></div></section>
        <button class="btn danger block" data-act="logout">${ic('logout', 18)} Sair da conta ${esc(u.name.split(' ')[0])}</button>`
    };
  };

  P.ajuda = () => ({
    title: 'Ajuda', back: '#/perfil', nav: 'perfil',
    html: `<section class="card"><h3>Sobre o projeto</h3><p><b>União dos Trabalhadores</b> é uma plataforma digital que conecta profissionais autônomos a clientes, reunindo divulgação, comunicação e organização profissional em um único aplicativo. Projeto acadêmico do IFPA – Campus Bragança.</p>
      <p class="notice">${ic('info', 16)} Este é um protótipo funcional sem servidor. Perfis, avaliações, pedidos e valores exibidos nos dados de demonstração são <b>fictícios</b>.</p></section>
      <section class="card faq"><h3>Perguntas frequentes</h3>
        <details><summary>Como contrato um serviço?</summary><p>No modo Cliente, abra o perfil do profissional, toque em "Solicitar serviço", escolha serviço, data e horário. Ele receberá o pedido e poderá aceitá-lo pelo chat ou pela Agenda.</p></details>
        <details><summary>Como alterno entre Cliente e Profissional?</summary><p>Em Perfil, toque em "Alternar para modo…". A conta é a mesma; só as telas e funções mudam.</p></details>
        <details><summary>Quando posso avaliar um profissional?</summary><p>Depois que o profissional marcar o serviço como concluído. Em Perfil › Meus pedidos aparece o botão "Avaliar serviço".</p></details>
        <details><summary>Como o faturamento é calculado?</summary><p>Ao concluir um serviço, o profissional informa o valor recebido. O sistema soma esses valores em relatórios semanais, mensais e anuais (estimativa).</p></details>
        <details><summary>Como funcionam as chamadas de voz?</summary><p>No protótipo, as chamadas funcionam entre duas abas/janelas do mesmo navegador (cada uma com um usuário). Para uso em redes diferentes seria necessário um servidor de sinalização.</p></details></section>`
  });
})();
