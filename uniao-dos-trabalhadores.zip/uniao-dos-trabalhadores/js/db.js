/* Camada de dados local: usuários, publicações, pedidos, avaliações, chat e notificações.
   Persistência em localStorage (dados) + IndexedDB (fotos, vídeos, áudios).
   Sincronização em tempo real entre abas via BroadcastChannel. Não há servidor. */
(function () {
  'use strict';
  const UT = (window.UT = window.UT || {});
  const KEY = 'ut_db_v1';
  const DAY = 86400000;

  UT.CATS = ['Cabeleireiro(a)', 'Diarista', 'Eletricista', 'Encanador', 'Pintor(a)', 'Professor(a) particular',
    'Fotógrafo(a)', 'Manicure', 'Técnico(a) de informática', 'Costureiro(a)', 'Pedreiro(a)', 'Mecânico(a)', 'Jardineiro(a)', 'Outro'];
  UT.CITIES = {
    'Bragança - PA': [-1.0536, -46.7656], 'Belém - PA': [-1.4558, -48.5044], 'Castanhal - PA': [-1.2939, -47.9264],
    'Capanema - PA': [-1.1953, -47.1811], 'São Paulo - SP': [-23.5505, -46.6333], 'Jundiaí - SP': [-23.1857, -46.8978],
    'Fortaleza - CE': [-3.7319, -38.5267], 'Rio de Janeiro - RJ': [-22.9068, -43.1729]
  };
  UT.REACTIONS = [{ k: 'like', e: '👍', l: 'Curtir' }, { k: 'love', e: '❤️', l: 'Amei' }, { k: 'clap', e: '👏', l: 'Parabéns' }, { k: 'wow', e: '😮', l: 'Uau' }];
  UT.WEEKDAYS = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado'];

  /* ---------- eventos e utilidades ---------- */
  const handlers = {};
  UT.on = (ev, fn) => { (handlers[ev] = handlers[ev] || []).push(fn); };
  UT.emit = (ev, d) => (handlers[ev] || []).forEach((f) => { try { f(d); } catch (e) { console.error(e); } });
  const bc = 'BroadcastChannel' in window ? new BroadcastChannel('ut_events') : null;
  UT.bc = bc;
  const uid = (p) => p + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  UT.uid = uid;
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  UT.ymd = ymd;
  UT.todayStr = () => ymd(new Date());
  UT.norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().trim();

  /* Senhas (RNF03): PBKDF2-SHA-256 (150 mil iterações) com sal individual, via Web Crypto.
     Sem servidor, isto protege apenas o dado armazenado no navegador; em produção a autenticação deve ficar no back-end.
     Em contextos não seguros (http fora de localhost) Web Crypto não existe e cai-se para um hash simples (legado). */
  const hex = (buf) => [...new Uint8Array(buf)].map((x) => x.toString(16).padStart(2, '0')).join('');
  const newSalt = () => hex((window.crypto || window.msCrypto).getRandomValues(new Uint8Array(16)));
  function legacyHash(p) {
    let h = 5381;
    for (const c of 'ut:' + p) h = ((h << 5) + h + c.charCodeAt(0)) >>> 0;
    return 'd:' + h;
  }
  async function hashPw(p, salt) {
    try {
      if (window.crypto && crypto.subtle) {
        const enc = new TextEncoder();
        const key = await crypto.subtle.importKey('raw', enc.encode(p), 'PBKDF2', false, ['deriveBits']);
        const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode('ut:' + (salt || '')), iterations: 150000, hash: 'SHA-256' }, key, 256);
        return 'p:' + hex(bits);
      }
    } catch (e) { /* cai para o hash simples */ }
    return legacyHash(p);
  }
  const checkPw = async (u, p) => {
    if (!u.pw) return false;
    if (u.pw.startsWith('p:')) return u.pw === (await hashPw(p, u.salt));
    if (u.pw.startsWith('d:')) return u.pw === legacyHash(p);
    const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('ut:' + p)); /* formato antigo "s:" */
    return u.pw === 's:' + hex(b);
  };

  UT.session = {
    get() { return sessionStorage.getItem('ut_s') || localStorage.getItem('ut_remember') || null; },
    set(id, remember) { sessionStorage.setItem('ut_s', id); if (remember) localStorage.setItem('ut_remember', id); },
    clear() { sessionStorage.removeItem('ut_s'); localStorage.removeItem('ut_remember'); }
  };

  /* ---------- mídia (IndexedDB) ---------- */
  const Media = (UT.Media = {
    cache: {}, miss: new Set(), pend: new Set(), _p: null,
    open() {
      if (!this._p) {
        this._p = new Promise((res, rej) => {
          const r = indexedDB.open('ut_media', 1);
          r.onupgradeneeded = () => r.result.createObjectStore('m');
          r.onsuccess = () => res(r.result);
          r.onerror = () => rej(r.error);
        });
      }
      return this._p;
    },
    async put(blob) {
      const db = await this.open();
      const id = uid('f_');
      await new Promise((res, rej) => {
        const t = db.transaction('m', 'readwrite');
        t.objectStore('m').put(blob, id);
        t.oncomplete = res; t.onerror = () => rej(t.error);
      });
      this.cache[id] = URL.createObjectURL(blob);
      return id;
    },
    url(id) {
      if (!id) return '';
      if (this.cache[id]) return this.cache[id];
      if (!this.pend.has(id) && !this.miss.has(id)) {
        this.pend.add(id);
        this.open().then((db) => new Promise((res) => {
          const rq = db.transaction('m').objectStore('m').get(id);
          rq.onsuccess = () => res(rq.result); rq.onerror = () => res(null);
        })).then((b) => {
          this.pend.delete(id);
          if (b) { this.cache[id] = URL.createObjectURL(b); UT.emit('media', id); } else this.miss.add(id);
        });
      }
      return '';
    },
    async del(id) {
      try {
        const db = await this.open();
        db.transaction('m', 'readwrite').objectStore('m').delete(id);
        delete this.cache[id];
      } catch (e) { /* ignora */ }
    }
  });

  UT.resizeImage = (file, max = 1600, q = 0.86) => new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, max / Math.max(img.width, img.height));
      const c = document.createElement('canvas');
      c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => (b ? resolve(b) : reject(new Error('Falha ao processar a imagem.'))), 'image/jpeg', q);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('Não foi possível ler a imagem.')); };
    img.src = url;
  });

  /* ---------- ilustrações de demonstração (placeholders) ---------- */
  const ART = {
    'Cabeleireiro(a)': ['scissors', '#7a45c9', '#c06ad9'], 'Diarista': ['sparkles', '#1f9d6b', '#58c9a0'],
    'Eletricista': ['zap', '#e08a1e', '#f2c14e'], 'Encanador': ['droplet', '#1f7fc9', '#59b6ee'],
    'Pintor(a)': ['brush', '#d6455d', '#f08a6b'], 'Professor(a) particular': ['book', '#3b5bdb', '#7c9bf5'],
    'Fotógrafo(a)': ['camera', '#4a2184', '#8e5ad6'], 'Manicure': ['sparkles', '#d4437f', '#f58bb5'],
    'Técnico(a) de informática': ['laptop', '#2b6f8f', '#5fb0cf'], 'Costureiro(a)': ['scissors', '#a8483a', '#e59377'],
    'Pedreiro(a)': ['wrench', '#8a6a3a', '#cfa66b'], 'Mecânico(a)': ['wrench', '#4a5568', '#8a9bb3'],
    'Jardineiro(a)': ['sparkles', '#2f9e44', '#8ad48f'], 'Outro': ['briefcase', '#5b2a9e', '#9a6be0']
  };
  UT.CAT_ICON = Object.fromEntries(Object.entries(ART).map(([k, v]) => [k, v[0]]));
  UT.art = (cat, n = 0) => {
    const [ic, c1, c2] = ART[cat] || ART.Outro;
    const rot = 20 + n * 35;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600"><defs><linearGradient id="g" gradientTransform="rotate(${rot} .5 .5)"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="800" height="600" fill="url(#g)"/><circle cx="${140 + n * 90}" cy="${120 + n * 30}" r="170" fill="#fff" fill-opacity=".10"/><circle cx="${700 - n * 60}" cy="520" r="210" fill="#fff" fill-opacity=".09"/><g transform="translate(296 186) scale(8.5)" fill="#fff" opacity=".92">${UT.icons[ic]}</g><text x="400" y="566" text-anchor="middle" font-family="Arial,sans-serif" font-size="22" fill="#fff" fill-opacity=".8">Imagem ilustrativa (demonstração)</text></svg>`;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  };

  /* ---------- estado ---------- */
  let db = null;
  const load = () => { try { return JSON.parse(localStorage.getItem(KEY)); } catch (e) { return null; } };
  function save() {
    try { localStorage.setItem(KEY, JSON.stringify(db)); }
    catch (e) { UT.emit('error', 'Armazenamento local cheio. Remova publicações ou mídias antigas.'); throw e; }
    if (bc) bc.postMessage({ t: 'db' });
  }
  const sync = () => { const f = load(); if (f && f.v) db = f; };
  const W = (fn) => (...a) => { sync(); const r = fn(...a); save(); return r; };

  const defAvail = () => ({
    weekly: {
      0: { on: false, start: '08:00', end: '12:00' }, 1: { on: true, start: '08:00', end: '18:00' }, 2: { on: true, start: '08:00', end: '18:00' },
      3: { on: true, start: '08:00', end: '18:00' }, 4: { on: true, start: '08:00', end: '18:00' }, 5: { on: true, start: '08:00', end: '18:00' },
      6: { on: true, start: '08:00', end: '12:00' }
    },
    blocked: []
  });
  const convKey = (a, b) => [a, b].sort().join('|');
  const emptyDB = (demo) => ({ v: 1, meta: { demo: !!demo }, users: [], posts: [], orders: [], reviews: [], messages: [], notifications: [], favorites: {} });

  /* ---------- semeadura (dados FICTÍCIOS de demonstração) ---------- */
  async function seedDB() {
    let s = 20261105;
    const rnd = () => { s |= 0; s = (s + 0x6D2B79F5) | 0; let t = Math.imul(s ^ (s >>> 15), 1 | s); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
    const pick = (a) => a[Math.floor(rnd() * a.length)];
    const pw = await hashPw('demo123', 'demo');
    const d = emptyDB(true);
    const BR = 'Bragança - PA';
    const mk = (id, name, email, city, mode, color, pro) => {
      const u = { id, name, email, pw, salt: 'demo', city, mode, color, avatarId: null, bio: '', pro: null, createdAt: Date.now() - 200 * DAY, prefs: {}, demo: true };
      if (pro) {
        u.pro = { category: pro.category, description: pro.description, avail: defAvail(),
          services: pro.services.map((x, i) => ({ id: `sv_${id}_${i}`, name: x[0], price: x[1] })) };
      }
      d.users.push(u); return u;
    };
    mk('u_juliana', 'Juliana Silva', 'juliana@demo.com', BR, 'cliente', 0);
    mk('u_ana', 'Ana Paula Mendes', 'ana@demo.com', BR, 'cliente', 3);
    mk('u_bruno', 'Bruno Teixeira', 'bruno@demo.com', BR, 'cliente', 4);
    mk('u_claudia', 'Cláudia Freitas', 'claudia@demo.com', BR, 'cliente', 2);
    mk('u_diego', 'Diego Nascimento', 'diego@demo.com', BR, 'cliente', 5);
    const clients = ['u_juliana', 'u_ana', 'u_bruno', 'u_claudia', 'u_diego'];
    const PROS = [
      ['u_carlos', 'Carlos Oliveira', 'carlos@demo.com', BR, 1, { category: 'Cabeleireiro(a)', description: 'Cabeleireiro especializado em cortes e coloração. Atendimento com hora marcada, ambiente climatizado e produtos de qualidade.', services: [['Corte masculino', 50], ['Coloração', 120], ['Barba', 30], ['Corte + barba', 70]] }],
      ['u_marina', 'Marina Costa', 'marina@demo.com', BR, 2, { category: 'Diarista', description: 'Limpeza residencial e comercial com capricho e pontualidade. Levo meus próprios materiais, se preferir.', services: [['Diária de limpeza', 120], ['Limpeza pós-obra', 250], ['Passar roupa (pacote)', 60]] }],
      ['u_rafael', 'Rafael Santos', 'rafael@demo.com', BR, 3, { category: 'Eletricista', description: 'Instalações e reparos elétricos residenciais e prediais, com garantia do serviço realizado.', services: [['Visita técnica', 60], ['Instalação de tomada/interruptor', 45], ['Troca de chuveiro elétrico', 80], ['Instalação de ventilador de teto', 90]] }],
      ['u_beatriz', 'Beatriz Lima', 'beatriz@demo.com', BR, 4, { category: 'Professor(a) particular', description: 'Reforço escolar em Matemática e Física para ensino fundamental e médio, com material de apoio.', services: [['Aula individual (1h)', 50], ['Pacote de 4 aulas', 180]] }],
      ['u_eduardo', 'Eduardo Matos', 'eduardo@demo.com', BR, 5, { category: 'Encanador', description: 'Reparo de vazamentos, desentupimentos e instalações hidráulicas em geral.', services: [['Desentupimento', 100], ['Reparo de vazamento', 90], ['Instalação de torneira', 60]] }],
      ['u_sandra', 'Sandra Nogueira', 'sandra@demo.com', BR, 0, { category: 'Costureiro(a)', description: 'Ajustes, barras e reformas de roupas com entrega no prazo combinado.', services: [['Ajuste de roupa', 35], ['Barra de calça', 20], ['Reforma de vestido', 90]] }],
      ['u_tiago', 'Tiago Ferreira', 'tiago@demo.com', 'Belém - PA', 2, { category: 'Pintor(a)', description: 'Pintura residencial e comercial, textura e grafiato, com acabamento de qualidade.', services: [['Pintura de cômodo', 350], ['Pintura de parede (por m²)', 18]] }],
      ['u_luana', 'Luana Pereira', 'luana@demo.com', 'Belém - PA', 3, { category: 'Fotógrafo(a)', description: 'Ensaios, retratos e cobertura de eventos, com entrega de galeria online.', services: [['Ensaio externo', 300], ['Cobertura de evento (2h)', 450]] }],
      ['u_camila', 'Camila Rocha', 'camila@demo.com', 'Castanhal - PA', 4, { category: 'Manicure', description: 'Esmaltação tradicional e em gel, com materiais esterilizados.', services: [['Mão', 30], ['Pé', 35], ['Mão e pé', 60]] }],
      ['u_pedro', 'Pedro Almeida', 'pedro@demo.com', 'São Paulo - SP', 5, { category: 'Técnico(a) de informática', description: 'Formatação, manutenção preventiva e remoção de vírus em notebooks e desktops.', services: [['Formatação', 90], ['Manutenção preventiva', 120], ['Remoção de vírus', 70]] }]
    ];
    PROS.forEach((p) => mk(p[0], p[1], p[2], p[3], 'profissional', p[4], p[5]));
    const U = (id) => d.users.find((u) => u.id === id);

    const at = (off, h, m = 0) => { const x = new Date(); x.setDate(x.getDate() + off); if (x.getDay() === 0) x.setDate(x.getDate() + (off < 0 ? -1 : 1)); x.setHours(h, m, 0, 0); return x; };
    const used = new Set();
    let on = 0, rn = 0;
    const addOrder = (cl, pr, si, off, h, status, extra = {}) => {
      const p = U(pr); const sv = p.pro.services[si % p.pro.services.length];
      let dt = at(off, h);
      while (used.has(pr + ymd(dt) + h)) { dt = at(off + 1, h); off += 1; }
      used.add(pr + ymd(dt) + h);
      const o = { id: 'o_seed' + (++on), clientId: cl, proId: pr, serviceId: sv.id, serviceName: sv.name, price: sv.price,
        date: ymd(dt), time: `${pad(h)}:00`, notes: '', status, createdAt: dt.getTime() - 2 * DAY, ...extra };
      if (status === 'concluido') {
        o.completedAt = dt.getTime() + 3600000;
        o.finalValue = extra.finalValue != null ? extra.finalValue : sv.price;
      }
      d.orders.push(o); return o;
    };
    const COMM = { 5: ['Excelente profissional, pontual e muito atencioso!', 'Serviço impecável, recomendo.', 'Superou minhas expectativas. Voltarei a contratar.', 'Atendimento ótimo e preço justo.', ''], 4: ['Muito bom, só atrasou um pouco no horário.', 'Bom trabalho, resultado como combinado.', ''], 3: ['Serviço bom, mas a comunicação poderia ser mais rápida.', ''] };
    const addReview = (o) => {
      const r = rnd(); const stars = r < 0.62 ? 5 : r < 0.92 ? 4 : 3;
      d.reviews.push({ id: 'r_seed' + (++rn), orderId: o.id, proId: o.proId, clientId: o.clientId, stars, comment: pick(COMM[stars]), at: o.completedAt + 4 * 3600000 });
    };
    // histórico de serviços concluídos (ao longo do ano para o profissional principal)
    const carlosOffs = [-1, -2, -3, -4, -6, -8, -9, -12, -15, -17, -20, -24, -30, -33, -38, -45, -52, -60, -75, -90, -110, -130, -150, -175, -200, -230, -260, -300];
    carlosOffs.forEach((off, i) => {
      const si = Math.floor(rnd() * 4); const sv = U('u_carlos').pro.services[si];
      const extra = si === 1 && rnd() < 0.4 ? { finalValue: 150 } : {};
      const o = addOrder(pick(clients), 'u_carlos', si, off, 9 + Math.floor(rnd() * 8), 'concluido', extra);
      if (rnd() < 0.8) addReview(o);
    });
    PROS.slice(1).forEach((p) => {
      const n = 3 + Math.floor(rnd() * 3);
      for (let i = 0; i < n; i++) {
        const o = addOrder(pick(clients.filter((c) => c !== 'u_juliana' || p[0] === 'u_marina' ? true : true)), p[0], i, -(3 + Math.floor(rnd() * 80)), 9 + Math.floor(rnd() * 8), 'concluido');
        if (rnd() < 0.85) addReview(o);
      }
    });
    // pedidos em andamento (cenário de demonstração)
    addOrder('u_ana', 'u_carlos', 0, 2, 10, 'pendente', { notes: 'Prefiro o período da manhã.' });
    addOrder('u_bruno', 'u_carlos', 3, 3, 9, 'pendente');
    addOrder('u_diego', 'u_carlos', 1, 1, 11, 'aceito');
    addOrder('u_claudia', 'u_carlos', 0, 1, 9, 'aceito');
    addOrder('u_juliana', 'u_carlos', 3, 5, 10, 'aceito', { notes: 'Primeira vez, tenho horário flexível.' });
    const jm = addOrder('u_juliana', 'u_marina', 0, -6, 14, 'concluido'); // sem avaliação: permite demonstrar RF11/RF12
    addOrder('u_juliana', 'u_rafael', 2, 2, 15, 'aceito');
    d.orders.forEach((o) => { if (o.status === 'concluido' && o.id === jm.id) { /* sem review */ } });

    // publicações
    const POSTS = {
      u_carlos: ['Corte degradê finalizado hoje! Agende seu horário pelo chat. 💈', 'Coloração com acabamento natural. Atendimento com hora marcada.'],
      u_marina: ['Casa de cliente após a limpeza completa. Agenda aberta para a próxima semana!'],
      u_rafael: ['Troca de quadro de distribuição concluída com segurança. Peça seu orçamento.'],
      u_beatriz: ['Vagas abertas para reforço em Matemática. Aulas individuais e em pequenos grupos.'],
      u_eduardo: ['Desentupimento e reparos hidráulicos com atendimento rápido.'],
      u_sandra: ['Ajustes e reformas de roupas com entrega no prazo.'],
      u_tiago: ['Fachada renovada! Pintura com acabamento de qualidade.'],
      u_luana: ['Ensaios externos com luz natural. Horários abertos neste mês.'],
      u_camila: ['Esmaltação em gel e tradicional. Agende seu horário.'],
      u_pedro: ['Manutenção preventiva evita dor de cabeça: limpeza interna e troca de pasta térmica.']
    };
    let k = 0;
    Object.keys(POSTS).forEach((pid) => {
      POSTS[pid].forEach((text, i) => {
        const p = { id: 'p_seed' + (++k), authorId: pid, text, media: [{ src: UT.art(U(pid).pro.category, i + k % 3), type: 'image' }],
          at: Date.now() - (k * 5 + i * 20) * 3600000, reactions: {}, comments: [], shares: 0 };
        const voters = clients.filter(() => rnd() < 0.6);
        voters.forEach((v) => { p.reactions[v] = pick(['like', 'like', 'love', 'clap', 'wow']); });
        d.posts.push(p);
      });
    });
    const P1 = d.posts[0];
    P1.comments.push({ id: 'c_seed1', userId: 'u_ana', text: 'Ficou ótimo! Já quero marcar o meu.', at: Date.now() - 3 * 3600000 });
    P1.comments.push({ id: 'c_seed2', userId: 'u_bruno', text: 'Atendimento nota 10.', at: Date.now() - 2 * 3600000 });
    d.posts[2].comments.push({ id: 'c_seed3', userId: 'u_juliana', text: 'Casa ficou brilhando, recomendo!', at: Date.now() - 6 * 3600000 });

    // conversas
    const msg = (a, b, text, minsAgo, read = true) => d.messages.push({ id: 'm_seed' + d.messages.length, conv: convKey(a, b), from: a, to: b, type: 'text', text, at: Date.now() - minsAgo * 60000, read });
    msg('u_juliana', 'u_carlos', 'Oi, Carlos! Você tem horário para um corte na próxima semana?', 190);
    msg('u_carlos', 'u_juliana', 'Olá, Juliana! Tenho sim. Pode solicitar pelo meu perfil, escolhendo o melhor horário.', 175);
    msg('u_juliana', 'u_carlos', 'Perfeito, já solicitei!', 160);
    msg('u_carlos', 'u_juliana', 'Recebi. Pedido confirmado, até lá!', 40, false);
    msg('u_juliana', 'u_marina', 'Muito obrigada pela limpeza de ontem, ficou ótimo!', 2000);
    msg('u_marina', 'u_juliana', 'Imagina! Qualquer coisa é só chamar.', 1990);
    msg('u_ana', 'u_carlos', 'Bom dia! Posso levar uma foto de referência?', 25, false);
    // notificações
    const nt = (u, text, link, icon, minsAgo, read = false) => d.notifications.push({ id: 'n_seed' + d.notifications.length, userId: u, text, link, icon, at: Date.now() - minsAgo * 60000, read });
    nt('u_carlos', 'Ana Paula Mendes solicitou "Corte masculino".', '#/agenda/pedidos', 'clipboard', 120);
    nt('u_carlos', 'Bruno Teixeira solicitou "Corte + barba".', '#/agenda/pedidos', 'clipboard', 90);
    nt('u_carlos', 'Cláudia Freitas curtiu sua publicação.', '#/inicio', 'heart', 300, true);
    nt('u_juliana', 'Carlos Oliveira aceitou seu pedido de "Corte + barba".', '#/pedidos', 'check', 60);
    nt('u_juliana', 'Seu serviço com Marina Costa foi concluído. Que tal avaliar?', '#/pedidos', 'star', 1400);
    d.favorites.u_juliana = ['u_carlos', 'u_marina'];
    return d;
  }

  /* ---------- inicialização ---------- */
  UT.init = async () => {
    db = load();
    if (!db || !db.v) { db = await seedDB(); try { save(); } catch (e) { /* ignorado */ } }
    if (bc) bc.onmessage = (e) => { if (e.data && e.data.t === 'db') { const f = load(); if (f && f.v) { db = f; UT.emit('change'); } } };
  };

  /* ---------- API de dados ---------- */
  const D = (UT.D = {});
  D.meta = () => db.meta;
  D.user = (id) => db.users.find((u) => u.id === id);
  D.users = () => db.users;
  D.pros = () => db.users.filter((u) => u.pro);
  D.snapshot = () => ({ msgs: db.messages.map((m) => m.id), notifs: db.notifications.map((n) => n.id) });

  D.register = async ({ name, email, password, city }) => {
    const salt = newSalt(); const pw = await hashPw(password, salt);
    return W(() => {
      email = email.trim().toLowerCase();
      if (db.users.some((u) => u.email === email)) throw new Error('Já existe uma conta com este e-mail.');
      const u = { id: uid('u_'), name: name.trim(), email, pw, salt, city: city.trim(), mode: null, color: Math.floor(Math.random() * 6), avatarId: null, bio: '', pro: null, createdAt: Date.now(), prefs: {} };
      db.users.push(u); return u;
    })();
  };
  D.login = async (email, password) => {
    sync();
    const u = db.users.find((x) => x.email === email.trim().toLowerCase());
    if (!u || !(await checkPw(u, password))) throw new Error('E-mail ou senha incorretos.');
    return u;
  };
  D.updateUser = W((id, patch) => { const u = D.user(id); Object.assign(u, patch); return u; });
  D.setMode = W((id, mode) => { D.user(id).mode = mode; });
  D.activatePro = W((id, { category, description, serviceName, price }) => {
    const u = D.user(id);
    u.pro = { category, description, avail: defAvail(), services: [{ id: uid('sv_'), name: serviceName, price: Number(price) }] };
    u.mode = 'profissional';
  });
  D.updatePro = W((id, patch) => { Object.assign(D.user(id).pro, patch); });
  D.saveService = W((proId, svc) => {
    const list = D.user(proId).pro.services;
    if (svc.id) { const s = list.find((x) => x.id === svc.id); s.name = svc.name; s.price = svc.price; }
    else list.push({ id: uid('sv_'), name: svc.name, price: svc.price });
  });
  D.deleteService = W((proId, id) => { const p = D.user(proId).pro; p.services = p.services.filter((s) => s.id !== id); });
  D.setAvail = W((proId, weekly) => { D.user(proId).pro.avail.weekly = weekly; });
  D.toggleBlocked = W((proId, date) => {
    const b = D.user(proId).pro.avail.blocked; const i = b.indexOf(date);
    if (i >= 0) b.splice(i, 1); else b.push(date);
    return i < 0;
  });
  D.deleteAccount = W((id) => {
    db.users = db.users.filter((u) => u.id !== id);
    db.posts = db.posts.filter((p) => p.authorId !== id);
    db.orders = db.orders.filter((o) => o.clientId !== id && o.proId !== id);
    db.messages = db.messages.filter((m) => m.from !== id && m.to !== id);
    db.notifications = db.notifications.filter((n) => n.userId !== id);
    delete db.favorites[id];
  });
  D.resetDemo = async () => { db = await seedDB(); save(); };
  D.wipe = () => { db = emptyDB(false); save(); };

  /* avaliações */
  D.reviewsOf = (proId) => db.reviews.filter((r) => r.proId === proId).sort((a, b) => b.at - a.at);
  D.rating = (proId) => {
    const r = D.reviewsOf(proId); if (!r.length) return { avg: 0, n: 0 };
    return { avg: r.reduce((s, x) => s + x.stars, 0) / r.length, n: r.length };
  };
  D.reviewOfOrder = (orderId) => db.reviews.find((r) => r.orderId === orderId);
  D.addReview = W(({ orderId, stars, comment }) => {
    const o = db.orders.find((x) => x.id === orderId);
    if (!o || o.status !== 'concluido' || !o.clientId) throw new Error('Este pedido não pode ser avaliado.');
    if (D.reviewOfOrder(orderId)) throw new Error('Este serviço já foi avaliado.');
    if (!(stars >= 1 && stars <= 5)) throw new Error('Escolha de 1 a 5 estrelas.');
    db.reviews.push({ id: uid('r_'), orderId, proId: o.proId, clientId: o.clientId, stars, comment: (comment || '').trim(), at: Date.now() });
    notify(o.proId, `${D.user(o.clientId).name} avaliou seu serviço com ${stars} estrela${stars > 1 ? 's' : ''}.`, '#/pro/' + o.proId, 'star');
  });

  /* pedidos e agenda */
  const fmtD = (s) => { const [y, m, d] = s.split('-'); return `${d}/${m}/${y}`; };
  const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
  D.slots = (proId, date) => {
    const u = D.user(proId); if (!u || !u.pro || !date) return [];
    const a = u.pro.avail; if (a.blocked.includes(date)) return [];
    const wd = new Date(date + 'T12:00:00').getDay(); const cfg = a.weekly[wd]; if (!cfg || !cfg.on) return [];
    const busy = new Set(db.orders.filter((o) => o.proId === proId && o.date === date && (o.status === 'pendente' || o.status === 'aceito')).map((o) => o.time));
    const now = new Date(); const isToday = date === ymd(now); const nowMin = now.getHours() * 60 + now.getMinutes();
    const out = [];
    for (let m = toMin(cfg.start); m + 60 <= toMin(cfg.end); m += 60) {
      const t = `${pad(Math.floor(m / 60))}:${pad(m % 60)}`;
      if (busy.has(t) || (isToday && m <= nowMin)) continue;
      out.push(t);
    }
    return out;
  };
  D.order = (id) => db.orders.find((o) => o.id === id);
  D.ordersOfPro = (id) => db.orders.filter((o) => o.proId === id);
  D.ordersOfClient = (id) => db.orders.filter((o) => o.clientId === id);
  D.createOrder = W(({ clientId, proId, serviceId, date, time, notes }) => {
    const pro = D.user(proId); const svc = pro && pro.pro && pro.pro.services.find((s) => s.id === serviceId);
    if (!svc) throw new Error('Selecione um serviço válido.');
    if (!date || !time) throw new Error('Escolha a data e o horário.');
    if (!D.slots(proId, date).includes(time)) throw new Error('Este horário não está mais disponível.');
    const o = { id: uid('o_'), clientId, proId, serviceId, serviceName: svc.name, price: svc.price, date, time, notes: (notes || '').trim(), status: 'pendente', createdAt: Date.now() };
    db.orders.push(o);
    pushMsg({ from: clientId, to: proId, type: 'order', orderId: o.id });
    notify(proId, `${D.user(clientId).name} solicitou "${svc.name}" para ${fmtD(date)} às ${o.time}.`, '#/agenda/pedidos', 'clipboard');
    return o;
  });
  D.createManual = W(({ proId, title, clientName, date, time, value }) => {
    if (!title || !date || !time) throw new Error('Informe título, data e horário.');
    const o = { id: uid('o_'), clientId: null, clientName: (clientName || '').trim() || 'Cliente externo', proId, serviceId: null, serviceName: title.trim(), price: Number(value) || 0, date, time, notes: '', status: 'aceito', manual: true, createdAt: Date.now() };
    db.orders.push(o); return o;
  });
  D.orderAct = W((id, action, actor, payload) => {
    const o = D.order(id); if (!o) throw new Error('Pedido não encontrado.');
    const isPro = actor === o.proId; const other = isPro ? o.clientId : o.proId; const me = D.user(actor);
    const sys = (text) => { if (o.clientId) pushMsg({ from: actor, to: other, type: 'system', text, read: true }); };
    if (action === 'accept' || action === 'refuse') {
      if (!isPro || o.status !== 'pendente') throw new Error('Ação não permitida.');
      o.status = action === 'accept' ? 'aceito' : 'recusado';
      sys(`${me.name} ${action === 'accept' ? 'aceitou' : 'recusou'} o pedido de "${o.serviceName}".`);
      notify(o.clientId, `${me.name} ${action === 'accept' ? 'aceitou' : 'recusou'} seu pedido de "${o.serviceName}".`, '#/pedidos', action === 'accept' ? 'check' : 'ban');
    } else if (action === 'cancel') {
      if (!['pendente', 'aceito'].includes(o.status)) throw new Error('Este pedido não pode mais ser cancelado.');
      if (actor !== o.clientId && !isPro) throw new Error('Ação não permitida.');
      o.status = 'cancelado'; o.canceledBy = actor;
      sys(`${me.name} cancelou o pedido de "${o.serviceName}".`);
      if (other) notify(other, `${me.name} cancelou o pedido de "${o.serviceName}".`, isPro ? '#/pedidos' : '#/agenda/pedidos', 'ban');
    } else if (action === 'complete') {
      if (!isPro || o.status !== 'aceito') throw new Error('Só é possível concluir pedidos aceitos.');
      const v = Number(payload && payload.value);
      if (!(v >= 0) || Number.isNaN(v)) throw new Error('Informe um valor válido.');
      o.status = 'concluido'; o.finalValue = v; o.completedAt = Date.now();
      sys(`${me.name} concluiu o serviço "${o.serviceName}".`);
      notify(o.clientId, `Seu serviço "${o.serviceName}" com ${me.name} foi concluído. Que tal avaliar?`, '#/pedidos', 'star');
    } else throw new Error('Ação inválida.');
    return o;
  });

  /* financeiro (RF15) */
  D.finance = (proId, period, offset = 0) => {
    const now = new Date(); let from; let to; const buckets = []; let label;
    const dm = (x) => `${pad(x.getDate())}/${pad(x.getMonth() + 1)}`;
    if (period === 'semana') {
      const b = new Date(now.getFullYear(), now.getMonth(), now.getDate() + offset * 7);
      from = new Date(b.getFullYear(), b.getMonth(), b.getDate() - b.getDay());
      to = new Date(from.getFullYear(), from.getMonth(), from.getDate() + 7);
      ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].forEach((l, i) => buckets.push({ label: l, start: +new Date(from.getFullYear(), from.getMonth(), from.getDate() + i), end: +new Date(from.getFullYear(), from.getMonth(), from.getDate() + i + 1), value: 0, count: 0 }));
      label = `${dm(from)} a ${dm(new Date(+to - DAY / 2))}`;
    } else if (period === 'mes') {
      from = new Date(now.getFullYear(), now.getMonth() + offset, 1); to = new Date(from.getFullYear(), from.getMonth() + 1, 1);
      const n = new Date(from.getFullYear(), from.getMonth() + 1, 0).getDate();
      for (let i = 0; i < n; i++) buckets.push({ label: String(i + 1), start: +new Date(from.getFullYear(), from.getMonth(), i + 1), end: +new Date(from.getFullYear(), from.getMonth(), i + 2), value: 0, count: 0 });
      label = from.toLocaleDateString('pt-BR', { month: 'long', year: 'numeric' });
    } else {
      from = new Date(now.getFullYear() + offset, 0, 1); to = new Date(from.getFullYear() + 1, 0, 1);
      ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'].forEach((l, i) => buckets.push({ label: l, start: +new Date(from.getFullYear(), i, 1), end: +new Date(from.getFullYear(), i + 1, 1), value: 0, count: 0 }));
      label = String(from.getFullYear());
    }
    const list = db.orders.filter((o) => o.proId === proId && o.status === 'concluido' && o.completedAt >= +from && o.completedAt < +to).sort((a, b) => b.completedAt - a.completedAt);
    const by = {};
    list.forEach((o) => {
      const b = buckets.find((x) => o.completedAt >= x.start && o.completedAt < x.end);
      if (b) { b.value += o.finalValue; b.count += 1; }
      by[o.serviceName] = by[o.serviceName] || { name: o.serviceName, total: 0, count: 0 };
      by[o.serviceName].total += o.finalValue; by[o.serviceName].count += 1;
    });
    const total = list.reduce((s, o) => s + o.finalValue, 0);
    return { label, buckets, list, total, count: list.length, avg: list.length ? total / list.length : 0, byService: Object.values(by).sort((a, b) => b.total - a.total) };
  };

  /* publicações */
  D.post = (id) => db.posts.find((p) => p.id === id);
  D.posts = () => db.posts.slice().sort((a, b) => b.at - a.at);
  D.createPost = W(({ authorId, text, media }) => {
    if (!text.trim() && !media.length) throw new Error('Escreva uma legenda ou adicione fotos/vídeos.');
    const p = { id: uid('p_'), authorId, text: text.trim(), media, at: Date.now(), reactions: {}, comments: [], shares: 0 };
    db.posts.push(p); return p;
  });
  D.updatePost = W((id, text) => { D.post(id).text = text.trim(); });
  D.deletePost = W((id) => { const p = D.post(id); db.posts = db.posts.filter((x) => x.id !== id); return p ? p.media.filter((m) => m.id).map((m) => m.id) : []; });
  D.react = W((id, userId, k) => {
    const p = D.post(id);
    if (p.reactions[userId] === k) delete p.reactions[userId];
    else {
      const first = !p.reactions[userId];
      p.reactions[userId] = k;
      if (first && p.authorId !== userId) notify(p.authorId, `${D.user(userId).name} reagiu à sua publicação.`, '#/post/' + id, 'heart');
    }
  });
  D.comment = W((id, userId, text) => {
    if (!text.trim()) throw new Error('Escreva um comentário.');
    const p = D.post(id);
    p.comments.push({ id: uid('c_'), userId, text: text.trim(), at: Date.now() });
    if (p.authorId !== userId) notify(p.authorId, `${D.user(userId).name} comentou na sua publicação.`, '#/post/' + id, 'chat');
  });
  D.delComment = W((id, cid) => { const p = D.post(id); p.comments = p.comments.filter((c) => c.id !== cid); });
  D.sharePost = W((id) => { D.post(id).shares += 1; });

  /* favoritos */
  D.favs = (uidv) => db.favorites[uidv] || [];
  D.toggleFav = W((uidv, proId) => {
    const l = (db.favorites[uidv] = db.favorites[uidv] || []); const i = l.indexOf(proId);
    if (i >= 0) l.splice(i, 1); else l.push(proId);
    return i < 0;
  });

  /* mensagens */
  function pushMsg(m) { const x = Object.assign({ id: uid('m_'), conv: convKey(m.from, m.to), at: Date.now(), read: false }, m); db.messages.push(x); return x; }
  function notify(userId, text, link, icon) { if (!userId) return; db.notifications.push({ id: uid('n_'), userId, text, link, icon: icon || 'bell', at: Date.now(), read: false }); }
  D.thread = (a, b) => db.messages.filter((m) => m.conv === convKey(a, b)).sort((x, y) => x.at - y.at);
  D.send = W((m) => pushMsg(m));
  D.addCallLog = W((m) => pushMsg(Object.assign({ type: 'call', read: m.status !== 'perdida' }, m)));
  D.convs = (me) => {
    const map = {};
    db.messages.forEach((m) => {
      if (m.from !== me && m.to !== me) return;
      const o = m.from === me ? m.to : m.from;
      const c = (map[o] = map[o] || { other: o, last: null, unread: 0 });
      if (!c.last || m.at > c.last.at) c.last = m;
      if (m.to === me && !m.read) c.unread += 1;
    });
    return Object.values(map).filter((c) => D.user(c.other)).sort((a, b) => b.last.at - a.last.at);
  };
  D.markRead = (me, other) => {
    let ch = false; const k = convKey(me, other);
    sync();
    db.messages.forEach((m) => { if (m.conv === k && m.to === me && !m.read) { m.read = true; ch = true; } });
    if (ch) save();
  };
  D.unreadMsgs = (me) => db.messages.filter((m) => m.to === me && !m.read).length;

  /* notificações */
  D.notifs = (me) => db.notifications.filter((n) => n.userId === me).sort((a, b) => b.at - a.at);
  D.unreadNotifs = (me) => db.notifications.filter((n) => n.userId === me && !n.read).length;
  D.readNotifs = (me) => {
    sync(); let ch = false;
    db.notifications.forEach((n) => { if (n.userId === me && !n.read) { n.read = true; ch = true; } });
    if (ch) save();
  };
})();
