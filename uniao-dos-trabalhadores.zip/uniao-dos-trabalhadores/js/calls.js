/* Chamadas de voz (RF08). Sinalização via BroadcastChannel + áudio via WebRTC.
   Limitação do protótipo: sem servidor, funciona entre abas/janelas do mesmo navegador. */
(function () {
  'use strict';
  const UT = window.UT; const D = UT.D; const { ic, esc } = UT;
  let cur = null;
  const meId = () => UT.session.get();
  const root = () => document.getElementById('call-root');
  const sig = (k, to, extra) => { if (UT.bc) UT.bc.postMessage(Object.assign({ t: 'call', k, from: meId(), to, cid: cur && cur.id }, extra || {})); };

  function ui() {
    const r = root(); if (!cur) { r.innerHTML = ''; r.hidden = true; return; }
    const p = D.user(cur.peer); r.hidden = false;
    const ringing = cur.status === 'ringing'; const calling = cur.status === 'calling'; const live = cur.status === 'connected';
    const text = calling ? 'Chamando…' : ringing ? 'Chamada de voz recebida' : live ? `Em chamada · ${UT.dur((Date.now() - cur.t0) / 1000)}` : 'Conectando…';
    let btns = '';
    if (ringing) btns = `<button class="call-btn red" data-call="decline" aria-label="Recusar chamada">${ic('phoneoff', 28)}</button><button class="call-btn green" data-call="accept" aria-label="Atender chamada">${ic('phone', 28)}</button>`;
    else btns = `${live ? `<button class="call-btn gray" data-call="mute" aria-label="${cur.muted ? 'Ativar microfone' : 'Silenciar microfone'}" aria-pressed="${!!cur.muted}">${ic('mic', 26)}</button>` : ''}<button class="call-btn red" data-call="end" aria-label="${calling ? 'Cancelar chamada' : 'Encerrar chamada'}">${ic('phoneoff', 28)}</button>`;
    r.innerHTML = `<div class="call-card" role="alertdialog" aria-live="assertive" aria-label="${esc(text)} com ${esc(p.name)}">${UT.avatar(p, 96)}<h2>${esc(p.name)}</h2><p id="call-status" class="${live ? 'live' : ''}">${text}</p><div class="call-btns ${cur.muted ? 'muted' : ''}">${btns}</div>${cur.nomic ? '<p class="small muted">Microfone indisponível: a chamada segue sem enviar áudio.</p>' : ''}</div><audio id="remote-audio" autoplay></audio>`;
    if (cur.remote) { const a = document.getElementById('remote-audio'); a.srcObject = cur.remote; a.play().catch(() => {}); }
  }
  function tick() { const s = document.getElementById('call-status'); if (cur && cur.status === 'connected' && s) s.textContent = `Em chamada · ${UT.dur((Date.now() - cur.t0) / 1000)}`; }
  setInterval(tick, 500);

  function teardown() {
    if (!cur) return; clearTimeout(cur.ringTimer);
    if (cur.stream) cur.stream.getTracks().forEach((t) => t.stop());
    if (cur.pc) { try { cur.pc.close(); } catch (e) { /* ignorado */ } }
    cur = null; ui();
  }
  async function mic() {
    try { return await navigator.mediaDevices.getUserMedia({ audio: true }); } catch (e) { cur.nomic = true; return null; }
  }
  async function startRTC(isCaller) {
    const pc = new RTCPeerConnection({ iceServers: [] }); cur.pc = pc; cur.pending = [];
    if (cur.stream) cur.stream.getTracks().forEach((t) => pc.addTrack(t, cur.stream)); else pc.addTransceiver('audio', { direction: 'recvonly' });
    pc.onicecandidate = (e) => { if (e.candidate) sig('ice', cur.peer, { cand: e.candidate.toJSON() }); };
    pc.ontrack = (e) => { cur.remote = e.streams[0]; const a = document.getElementById('remote-audio'); if (a) { a.srcObject = cur.remote; a.play().catch(() => {}); } };
    if (isCaller) { const off = await pc.createOffer(); await pc.setLocalDescription(off); sig('offer', cur.peer, { sdp: pc.localDescription.toJSON() }); }
  }
  function logCall(status) {
    if (!cur || cur.role !== 'caller' || cur.logged) return; cur.logged = true;
    const dur = cur.t0 ? (Date.now() - cur.t0) / 1000 : 0;
    D.addCallLog({ from: meId(), to: cur.peer, status, duration: dur });
    if (UT.view && UT.view.thread) UT.updateThread(true);
  }

  UT.startCall = async (peer) => {
    if (cur) { UT.toast('Você já está em uma chamada.', 'error'); return; }
    cur = { id: UT.uid('call_'), peer, role: 'caller', status: 'calling' };
    cur.stream = await mic(); ui();
    sig('ring', peer);
    cur.ringTimer = setTimeout(() => { if (cur && cur.status === 'calling') { sig('cancel', cur.peer); logCall('perdida'); UT.toast(`${D.user(cur.peer).name} não atendeu.`, 'info'); teardown(); } }, 30000);
  };

  async function accept() {
    cur.status = 'connected'; cur.t0 = Date.now(); cur.stream = await mic(); ui();
    await startRTC(false); sig('accept', cur.peer);
  }
  function hangup() {
    if (!cur) return; const peer = cur.peer;
    if (cur.status === 'ringing') sig('decline', peer);
    else { sig(cur.status === 'calling' ? 'cancel' : 'end', peer); logCall(cur.status === 'connected' ? 'atendida' : 'perdida'); }
    teardown();
  }

  async function onSignal(m) {
    if (!m || m.t !== 'call' || m.to !== meId()) return;
    if (m.k === 'ring') {
      if (cur) { UT.bc.postMessage({ t: 'call', k: 'busy', from: meId(), to: m.from, cid: m.cid }); return; }
      cur = { id: m.cid, peer: m.from, role: 'callee', status: 'ringing' }; ui(); return;
    }
    if (!cur || cur.id !== m.cid) return;
    try {
      if (m.k === 'accept') { clearTimeout(cur.ringTimer); cur.status = 'connected'; cur.t0 = Date.now(); ui(); await startRTC(true); }
      else if (m.k === 'decline' || m.k === 'busy') { logCall('recusada'); UT.toast(m.k === 'busy' ? 'O usuário está em outra chamada.' : 'Chamada recusada.', 'info'); teardown(); }
      else if (m.k === 'cancel') { teardown(); }
      else if (m.k === 'end') { logCall(cur.status === 'connected' ? 'atendida' : 'perdida'); UT.toast('Chamada encerrada.', 'info'); teardown(); }
      else if (m.k === 'offer' && cur.pc) {
        await cur.pc.setRemoteDescription(m.sdp); (cur.pending || []).forEach((c) => cur.pc.addIceCandidate(c).catch(() => {})); cur.pending = null;
        const ans = await cur.pc.createAnswer(); await cur.pc.setLocalDescription(ans); sig('answer', cur.peer, { sdp: cur.pc.localDescription.toJSON() });
      } else if (m.k === 'answer' && cur.pc) {
        await cur.pc.setRemoteDescription(m.sdp); (cur.pending || []).forEach((c) => cur.pc.addIceCandidate(c).catch(() => {})); cur.pending = null;
      } else if (m.k === 'ice' && cur.pc) {
        if (cur.pending) cur.pending.push(m.cand); else cur.pc.addIceCandidate(m.cand).catch(() => {});
      }
    } catch (e) { console.warn('Falha na sinalização da chamada', e); }
  }
  if (UT.bc) UT.bc.addEventListener('message', (e) => onSignal(e.data));

  document.addEventListener('click', (e) => {
    const b = e.target.closest('[data-call]'); if (!b || !cur) return;
    const k = b.dataset.call;
    if (k === 'accept') accept(); else if (k === 'decline' || k === 'end') hangup();
    else if (k === 'mute') { cur.muted = !cur.muted; if (cur.stream) cur.stream.getAudioTracks().forEach((t) => { t.enabled = !cur.muted; }); ui(); }
  });
})();
