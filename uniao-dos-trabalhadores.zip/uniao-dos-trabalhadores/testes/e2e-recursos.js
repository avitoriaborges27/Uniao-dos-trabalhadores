/* Segunda bateria de testes: cadastro/validações, perfil, serviços, agenda, publicações com imagem, favoritos, geolocalização, acessibilidade.
   Uso: node testes/e2e-recursos.js [URL] */
const { chromium } = require('playwright');
const URL = process.argv[2] || 'http://localhost:8765/index.html';
let pass = 0, total = 0; const errors = [];
const ok = (n, c, x = '') => { total++; if (c) pass++; console.log((c ? 'PASS' : 'FAIL') + '  ' + n + (!c && x ? '  -> ' + x : '')); };
const step = async (n, f) => { try { await f(); } catch (e) { total++; console.log('FAIL  ' + n + '  -> ' + e.message.split('\n')[0]); } };
(async () => {
  const browser = await chromium.launch({ args: ['--lang=pt-BR'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, locale: 'pt-BR', permissions: ['geolocation'], geolocation: { latitude: -1.05, longitude: -46.76 } });
  const p = await ctx.newPage(); p.setDefaultTimeout(5000);
  p.on('pageerror', (e) => errors.push(e.message)); p.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
  const go = async (h) => { await p.goto(URL + h); await p.waitForTimeout(250); };
  const body = async () => (await p.textContent('body')).replace(/\s+/g, ' ');

  await step('login inválido', async () => {
    await go('#/login'); await p.fill('input[name=email]', 'juliana@demo.com'); await p.fill('input[name=password]', 'errada'); await p.click('form[data-form=login] button.primary'); await p.waitForTimeout(300);
    ok('RNF03 login com senha errada é recusado', /#\/login/.test(p.url()) && (await p.textContent('#form-err')).length > 0, await p.textContent('#form-err'));
  });
  await step('cadastro validações', async () => {
    await go('#/signup'); await p.fill('input[name=name]', 'Fulano Teste'); await p.fill('input[name=email]', 'juliana@demo.com'); await p.fill('input[name=password]', 'abc123'); await p.fill('input[name=city]', 'Bragança - PA'); await p.check('input[name=terms]');
    await p.click('form[data-form=signup] button.primary'); await p.waitForTimeout(300);
    ok('RF01 e-mail duplicado é recusado', /#\/signup/.test(p.url()) && (await p.textContent('#form-err')).length > 0);
    await p.fill('input[name=email]', 'fulano@teste.com'); await p.fill('input[name=password]', '123');
    await p.evaluate(() => document.querySelector('form[data-form=signup]').setAttribute('novalidate', ''));
    await p.click('form[data-form=signup] button.primary'); await p.waitForTimeout(200);
    ok('RNF03 senha curta é recusada', /ao menos 6/.test(await p.textContent('#form-err')));
  });
  await step('segurança do armazenamento', async () => {
    const raw = await p.evaluate(() => localStorage.getItem('ut_db_v1') || '');
    ok('RNF03 senhas não ficam em texto puro no armazenamento', raw.length > 0 && !raw.includes('demo123'));
  });
  await step('ativar profissional + alternar modo', async () => {
    await go('#/login'); await p.click('[data-email="juliana@demo.com"]'); await p.waitForURL(/#\/inicio/);
    await go('#/perfil'); await p.click('#main [data-act=swap-mode]'); await p.waitForTimeout(500);
    const t = await body(); ok('RF02 Juliana (cliente) pode ativar o modo profissional com a mesma conta', /Perfil profissional|Ativar/.test(t));
    await p.selectOption('select[name=category]', { index: 2 }); await p.fill('textarea[name=description]', 'Instalações elétricas residenciais.'); await p.fill('input[name=serviceName]', 'Visita técnica'); await p.fill('input[name=price]', '90');
    await p.click('form[data-form=activate-pro] button.primary'); await p.waitForURL(/#\/inicio/);
    ok('RF03/RF04 após ativar, modo Profissional exibido abaixo do nome', /Profissional/.test(await p.textContent('.chip-user')));
    await go('#/perfil'); await p.click('#main [data-act=swap-mode]');
    await p.waitForTimeout(400); ok('RF02 alternar de volta para Cliente', /Cliente/.test(await p.textContent('.chip-user')));
  });
  await step('editar perfil cliente', async () => {
    await go('#/editar-perfil'); await p.fill('input[name=city]', 'Belém - PA'); await p.click('form[data-form=edit-profile] button.primary'); await p.waitForTimeout(400);
    await go('#/inicio'); ok('RF05/RF06 feed usa a cidade do perfil atualizado', /Belém - PA/.test(await p.innerText('#main')));
    await go('#/editar-perfil'); await p.fill('input[name=city]', 'Bragança - PA'); await p.click('form[data-form=edit-profile] button.primary'); await p.waitForTimeout(300);
  });
  await step('busca: geolocalização e filtros', async () => {
    await go('#/buscar'); await p.click('[data-act=use-location]'); await p.waitForTimeout(700);
    const city = await p.inputValue('[data-change=search-city]'); ok('RF05 "Usar minha localização" seleciona a cidade mais próxima', /Bragança/.test(city), city);
    await p.selectOption('[data-change=search-cat]', { label: 'Eletricista' }).catch(() => {}); await p.waitForTimeout(200);
    ok('RF05 filtro por categoria', /Eletricista|nenhum|Nenhum|encontrado/.test(await p.textContent('#res-count')));
  });
  await step('favoritos', async () => {
    await p.selectOption('[data-change=search-cat]', ''); await p.waitForTimeout(200);
    await p.locator('#results [data-act=fav]').first().click(); await p.waitForTimeout(300); await go('#/favoritos');
    ok('favoritos: profissional salvo aparece na lista', await p.locator('a[href^="#/pro/"]').count() > 0);
  });
  await step('logout', async () => { await go('#/config'); await p.click('[data-act=logout]'); await p.click('[data-act=confirm-ok]'); await p.waitForTimeout(400); ok('sair da conta volta às boas-vindas', /#\/welcome/.test(p.url())); });

  /* ---- profissional: serviços, agenda, publicação com imagem ---- */
  await step('profissional: serviços (CRUD)', async () => {
    await go('#/login'); await p.click('[data-email="carlos@demo.com"]'); await p.waitForURL(/#\/inicio/); await go('#/servicos');
    const before = await p.locator('[data-act=svc-edit]').count();
    await p.click('[data-act=svc-new]'); await p.fill('form[data-form=service] input[name=name]', 'Hidratação'); await p.fill('form[data-form=service] input[name=price]', '45'); await p.click('form[data-form=service] button.primary'); await p.waitForTimeout(400);
    ok('RF/diagrama: adicionar serviço com preço', /Hidratação/.test(await p.textContent('#main')) && await p.locator('[data-act=svc-edit]').count() === before + 1);
    await p.locator('[data-act=svc-edit]').last().click(); await p.fill('form[data-form=service] input[name=price]', '50'); await p.click('form[data-form=service] button.primary'); await p.waitForTimeout(300);
    ok('editar serviço', /R\$\s?50,00/.test(await p.textContent('#main')));
    await p.locator('[data-act=svc-del]').last().click(); await p.click('[data-act=confirm-ok]'); await p.waitForTimeout(300);
    ok('excluir serviço', !/Hidratação/.test(await p.textContent('#main')));
  });
  await step('agenda: bloquear dia, horários, compromisso manual', async () => {
    await go('#/agenda'); await p.click('[data-act=toggle-block]'); await p.waitForTimeout(300);
    ok('RF14 bloquear dia', /liberar|Liberar/.test(await p.textContent('#cal')) || /Bloqueado/.test(await p.textContent('#cal')));
    await p.click('[data-act=toggle-block]'); await p.waitForTimeout(200);
    await p.fill('input[name=start1]', '09:00'); await p.fill('input[name=end1]', '17:00'); await p.click('form[data-form=avail] button.primary'); await p.waitForTimeout(300);
    ok('RF14 editar horários disponíveis', /salvos/.test(await p.textContent('#toasts')));
    await p.click('[data-act=new-manual]'); await p.waitForSelector('form[data-form=manual]');
    await p.fill('form[data-form=manual] input[name=title]', 'Corte avulso'); await p.fill('form[data-form=manual] input[name=clientName]', 'Cliente de balcão');
    await p.locator('form[data-form=manual] input[name=time]').fill('15:00').catch(() => {}); await p.locator('form[data-form=manual] input[name=value]').fill('40').catch(() => {});
    await p.click('form[data-form=manual] button.primary'); await p.waitForTimeout(400);
    ok('RF14 compromisso manual criado na agenda', /Corte avulso/.test(await p.textContent('#main')));
  });
  await step('publicação com imagem', async () => {
    await go('#/inicio'); const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/q842iQAAAABJRU5ErkJggg==', 'base64');
    await p.setInputFiles('#post-files', { name: 'trabalho.png', mimeType: 'image/png', buffer: png }); await p.waitForTimeout(600);
    ok('RF10 pré-visualização do anexo', await p.locator('#draft img, #draft .thumb, #draft [data-act=draft-remove]').count() > 0);
    await p.fill('#post-text', 'Post de teste com imagem'); await p.click('form[data-form=new-post] button.primary'); await p.waitForTimeout(700);
    ok('RF10 publicação com foto criada', /Post de teste com imagem/.test(await p.textContent('#main')) && await p.locator('.post').first().locator('img').count() > 0);
    await p.locator('.post').first().locator('[data-act=delete-post]').click(); await p.click('[data-act=confirm-ok]'); await p.waitForTimeout(400);
    ok('RF10 remover publicação', !/Post de teste com imagem/.test(await p.textContent('#main')));
  });
  await step('acessibilidade', async () => {
    await go('#/config'); await p.click('label:has([data-k=large])'); await p.waitForTimeout(150);
    ok('RNF01 opção Texto maior altera o tamanho da fonte', await p.evaluate(() => document.documentElement.dataset.large) === '1');
    await p.click('label:has([data-k=large])');
    ok('acessibilidade: link "Ir para o conteúdo" e landmarks', await p.locator('a.skip').count() === 1 && await p.locator('main#main').count() === 1 && await p.locator('nav[aria-label]').count() >= 1);
  });
  await step('modo escuro', async () => {
    await go('#/config'); await p.click('label:has(input[name=theme][value=dark])'); await p.waitForTimeout(200);
    const bg = await p.evaluate(() => getComputedStyle(document.body).backgroundColor);
    ok('Tema escuro aplica data-theme e fundo escuro (persistente)', await p.evaluate(() => document.documentElement.dataset.theme) === 'dark' && /rgb\(14, 11, 25\)/.test(bg), bg);
    await go('#/inicio'); ok('Tema escuro persiste ao trocar de tela', await p.evaluate(() => document.documentElement.dataset.theme) === 'dark');
    await go('#/config'); await p.click('label:has(input[name=theme][value=light])'); await p.waitForTimeout(150);
    ok('Tema claro restaurado', await p.evaluate(() => document.documentElement.dataset.theme) === 'light');
    await p.click('label:has(input[name=theme][value=auto])');
  });
  await step('desktop responsivo', async () => {
    await p.setViewportSize({ width: 1440, height: 900 }); await go('#/inicio');
    ok('RNF04 layout de computador usa menu lateral', await p.locator('aside.side').isVisible());
    await p.setViewportSize({ width: 390, height: 844 }); await p.waitForTimeout(150);
    ok('RNF04 layout de celular usa barra inferior', await p.locator('nav.tabbar').isVisible());
  });
  console.log(`\n${pass}/${total} verificações passaram`); console.log(errors.length ? 'ERROS DE CONSOLE:\n' + [...new Set(errors)].join('\n') : 'Sem erros de console.');
  await browser.close();
})();
