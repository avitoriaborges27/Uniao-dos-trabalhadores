/* Teste ponta a ponta (Playwright). Uso: node testes/e2e.js [URL]
   Sobe o app em URL (padrão http://localhost:8765/index.html) e executa os fluxos reais com duas abas
   (duas sessões de usuário no mesmo navegador, compartilhando o armazenamento local = "tempo real" entre abas). */
const { chromium } = require('playwright');
const URL = process.argv[2] || 'http://localhost:8765/index.html';
const results = []; let errors = [];
const ok = (name, cond, extra = '') => { results.push({ name, pass: !!cond, extra }); console.log((cond ? 'PASS' : 'FAIL') + '  ' + name + (extra && !cond ? '  -> ' + extra : '')); };
const step = async (name, fn) => { try { await fn(); } catch (e) { ok(name, false, e.message.split('\n')[0]); } };

(async () => {
  const browser = await chromium.launch({ args: ['--lang=pt-BR', '--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'] });
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, permissions: ['microphone', 'geolocation'], geolocation: { latitude: -23.55, longitude: -46.63 }, locale: 'pt-BR' });
  const mk = async () => { const p = await ctx.newPage(); p.on('pageerror', (e) => errors.push('PAGEERROR ' + e.message)); p.on('console', (m) => { if (m.type() === 'error') errors.push('console.error ' + m.text()); }); return p; };
  const A = await mk(); const B = await mk(); A.setDefaultTimeout(5000); B.setDefaultTimeout(5000);
  const txt = async (p) => (await p.innerText('body')).replace(/\s+/g, ' ');

  await A.goto(URL); await B.goto(URL);
  await step('boas-vindas', async () => ok('RF01 tela de boas-vindas', /Bem-vindo/.test(await txt(A))));

  /* cadastro novo (RF01) + escolha de modo (RF02) */
  await step('cadastro', async () => {
    await A.click('a[href="#/signup"]'); await A.waitForSelector('form[data-form=signup]');
    await A.fill('input[name=name]', 'Teste Silva'); await A.fill('input[name=email]', 'teste' + Date.now() + '@ex.com');
    await A.fill('input[name=password]', 'senha123'); await A.fill('input[name=city]', 'São Paulo - SP');
    await A.check('input[name=terms]'); await A.click('form[data-form=signup] button.primary');
    await A.waitForURL(/#\/modo/); await A.waitForSelector('.mode-cards'); ok('RF01 cadastro único leva à escolha de modo', /Escolha seu modo/.test(await txt(A)));
    await A.click('[data-act=choose-mode][data-mode=cliente], [data-mode=cliente]'); await A.waitForURL(/#\/inicio/);
    ok('RF02/RF04 modo Cliente exibido sob o nome', /Cliente/.test(await A.textContent('.chip-user')));
  });
  /* login demo */
  await step('login demo', async () => {
    await B.goto(URL + '#/login'); await B.click('[data-email="carlos@demo.com"]'); await B.waitForURL(/#\/inicio/);
    ok('login demo profissional (Carlos)', /Profissional/.test(await B.textContent('.chip-user')));
  });
  await A.evaluate(() => { sessionStorage.clear(); }); await A.goto(URL + '#/login'); await A.reload();
  await A.click('[data-email="juliana@demo.com"]'); await A.waitForURL(/#\/inicio/);
  ok('login demo cliente (Juliana)', /Cliente/.test(await A.textContent('.chip-user')));

  /* feed (RF06, RF07, RF09) */
  await step('feed', async () => {
    const n = await A.locator('.post').count(); ok('RF06/RF07 feed com publicações', n > 0, 'posts=' + n);
    const first = A.locator('.post').first();
    const before = await first.locator('[data-act=react-toggle].on').count();
    await first.locator('[data-act=react-toggle]').click(); await A.waitForTimeout(250);
    const after = await A.locator('.post').first().locator('[data-act=react-toggle].on').count();
    ok('RF09 curtida/reação alterna e persiste', before !== after, `antes=${before} depois=${after}`);
    await first.locator('[data-act=toggle-comments]').click();
    await first.locator('input[name=text]').fill('Ótimo trabalho!'); await first.locator('input[name=text]').press('Enter');
    await A.waitForTimeout(300); const pt = await A.locator('.post').first().textContent(); ok('RF09 comentário publicado', pt.includes('Ótimo trabalho!'), pt.replace(/\s+/g, ' ').slice(0, 200));
  });
  /* busca (RF05) */
  await step('busca', async () => {
    await A.goto(URL + '#/buscar'); await A.waitForSelector('#results');
    const total = await A.locator('#results .pro-card, #results article, #results li').count();
    ok('RF05 busca lista profissionais da cidade', total > 0, 'itens=' + total);
    await A.fill('[data-input=search-q]', 'cabele'); await A.waitForTimeout(200);
    ok('RF05 busca por texto filtra', /Carlos/.test(await A.innerText('#results')));
  });
  /* perfil público (RF13) + contratação (pedido) */
  await step('pedido', async () => {
    await A.goto(URL + '#/buscar'); await A.fill('[data-input=search-q]', 'Carlos');
    await A.locator('#results a[href^="#/pro/"]').first().click(); await A.waitForURL(/#\/pro\//);
    await A.waitForSelector('text=Serviços e preços'); const t = await txt(A);
    ok('RF13 perfil público com avaliações e serviços', /avalia/i.test(t) && /Corte masculino/.test(t));
    await A.click('[data-act=request]'); await A.waitForSelector('form[data-form=request-order]');
    await A.waitForSelector('#slots button'); await A.locator('#slots button:not([disabled])').first().click();
    await A.fill('textarea[name=notes]', 'Corte às pressas, por favor.'); await A.click('form[data-form=request-order] button.primary');
    await A.waitForTimeout(400); ok('pedido criado', /Pedido enviado|pedido/i.test(await txt(A)));
  });
  /* tempo real: Carlos (aba B) recebe notificação + pedido (RNF07) */
  await step('tempo real', async () => {
    await B.waitForTimeout(600);
    const nb = await B.locator('[data-badge=notif]:not([hidden])').count();
    ok('RNF07 notificação chega à outra aba sem recarregar', nb > 0);
    await B.goto(URL + '#/agenda'); await B.waitForTimeout(300);
    ok('RF14 agenda do profissional exibe pedido pendente', /Aceitar/.test(await txt(B)) || /pendente/i.test(await txt(B)));
  });
  /* Carlos aceita e conclui (RF15) */
  await step('aceitar e concluir', async () => {
    await B.goto(URL + '#/agenda/pedidos'); await B.waitForSelector('[data-act=order-accept]');
    const acc = B.locator('[data-act=order-accept]').first(); await acc.click(); await B.waitForTimeout(300);
    const comp = B.locator('[data-act=order-complete]').first(); await comp.click();
    await B.waitForSelector('form[data-form=complete-order]'); await B.fill('form[data-form=complete-order] input[name=value]', '55');
    await B.click('form[data-form=complete-order] button.primary'); await B.waitForTimeout(400);
    await B.goto(URL + '#/agenda/financeiro'); await B.waitForTimeout(400);
    const ft = await B.innerText('#main'); ok('RF15 valor concluído registrado no faturamento (R$ 55,00)', /55,00/.test(ft), ft.slice(0, 160).replace(/\n/g, ' '));
    ok('RF15 relatórios semanal/mensal/anual', /Semanal/i.test(ft) && /Mensal/i.test(ft) && /Anual/i.test(ft));
  });
  /* avaliação (RF11/RF12) */
  await step('avaliação', async () => {
    await A.goto(URL + '#/pedidos'); await A.waitForTimeout(300);
    await A.locator('[data-act=order-review]').first().click(); await A.waitForSelector('form[data-form=review]');
    await A.locator('.star-input button').nth(4).click(); await A.fill('form[data-form=review] textarea', 'Atendimento excelente, recomendo!');
    await A.click('form[data-form=review] button.primary'); await A.waitForTimeout(400);
    ok('RF11/RF12 avaliação enviada (sem botão Avaliar para o pedido)', /Atendimento excelente/.test(await txt(A)));
    await A.goto(URL + '#/buscar'); await A.fill('[data-input=search-q]', 'Carlos'); await A.locator('#results a[href^="#/pro/"]').first().click(); await A.waitForTimeout(300);
    ok('RF13 avaliação aparece no perfil público', /Atendimento excelente/.test(await txt(A)));
  });
  /* chat (RF08) */
  await step('chat texto', async () => {
    await A.click('a[href^="#/chat/"], [data-act=chat]').catch(async () => { await A.goto(URL + '#/chat'); });
    await A.waitForTimeout(300);
    if (!/#\/chat\//.test(A.url())) { await A.locator('a[href^="#/chat/"]').first().click(); }
    await A.waitForSelector('form[data-form=send-msg]'); await A.fill('form[data-form=send-msg] input[name=text]', 'Olá Carlos, tudo bem?'); await A.press('form[data-form=send-msg] input[name=text]', 'Enter');
    await A.waitForTimeout(300); ok('RF08 mensagem de texto enviada', /Olá Carlos, tudo bem\?/.test(await A.innerText('#msgs')));
    await B.goto(URL + '#/chat'); await B.waitForTimeout(400);
    ok('RNF07 mensagem aparece para o outro usuário', /Olá Carlos|Juliana/.test(await txt(B)));
  });
  await step('chat voz', async () => {
    await A.click('[data-act=rec-start]'); await A.waitForTimeout(1500); await A.click('[data-act=rec-send]'); await A.waitForTimeout(500);
    ok('RF08 mensagem de voz gravada e enviada', await A.locator('#msgs audio, #msgs .voice, #msgs [data-voice]').count() > 0);
  });
  await step('chamada', async () => {
    await A.click('[data-act=call]'); await A.waitForTimeout(600);
    ok('RF08 tela de chamada aparece', await A.locator('#call-root:not([hidden])').count() === 1);
    await B.waitForTimeout(500);
    ok('RF08/RNF07 chamada recebida na outra aba', await B.locator('#call-root:not([hidden])').count() === 1);
    await B.locator('#call-root [data-call=accept]').click(); await B.waitForTimeout(1500);
    ok('RF08 chamada atendida e conectada nas duas pontas', /Em chamada/.test(await B.innerText('#call-root')) && /Em chamada/.test(await A.innerText('#call-root')), 'A=' + (await A.innerText('#call-root')).replace(/\s+/g,' ').slice(0,80));
    await A.locator('#call-root [data-call=end]').click(); await A.waitForTimeout(800);
    ok('RF08 desligar encerra a chamada nas duas pontas', await A.locator('#call-root:not([hidden])').count() === 0 && await B.locator('#call-root:not([hidden])').count() === 0,
      'A visível=' + await A.locator('#call-root:not([hidden])').count() + ' B visível=' + await B.locator('#call-root:not([hidden])').count());
  });
  /* financeiro (RF15) */
  await step('financeiro', async () => {
    await B.goto(URL + '#/inicio'); await B.waitForTimeout(300);
    const t = await txt(B); ok('RF15 modo profissional mostra faturamento', /R\$/.test(t));
  });
  /* alternar modo e publicar (RF10) */
  await step('publicar', async () => {
    await B.goto(URL + '#/inicio'); await B.waitForSelector('form[data-form=new-post]');
    await B.fill('form[data-form=new-post] textarea[name=text]', 'Corte degradê feito hoje!'); await B.click('form[data-form=new-post] button.primary'); await B.waitForTimeout(400);
    ok('RF10 publicação criada', /Corte degradê feito hoje/.test(await txt(B)));
    await A.goto(URL + '#/buscar'); await A.goto(URL + '#/inicio'); await A.waitForTimeout(400);
    ok('RF07 publicação nova aparece no feed do cliente', /Corte degradê feito hoje/.test(await txt(A)) || (await A.evaluate(() => document.body.textContent)).includes('Corte degradê feito hoje'));
  });
  /* alternar modo (RF02/RF03) */
  await step('swap', async () => {
    await A.evaluate(() => document.querySelector('[data-act=swap-mode]').click()); await A.waitForTimeout(500);
    ok('RF02/RF03 alternância de modo (cliente → profissional)', /Ativar|Profissional/.test(await txt(A)));
  });
  console.log('\n' + results.filter(r => r.pass).length + '/' + results.length + ' verificações passaram');
  const uniq = [...new Set(errors)]; console.log(uniq.length ? 'ERROS DE CONSOLE:\n' + uniq.join('\n') : 'Sem erros de console.');
  await browser.close();
})();
