# União dos Trabalhadores — protótipo funcional

Implementação do projeto **"União dos Trabalhadores: conectando profissionais autônomos às oportunidades"**
(IFPA – Campus Bragança). Plataforma que une **marketplace de serviços**, **rede social** (feed, reações, comentários)
e **gestão profissional** (agenda, pedidos, faturamento) em uma única aplicação, com **uma conta e dois modos de uso**:
**Cliente** e **Profissional**.

> **Natureza do protótipo.** O artigo descreve requisitos e telas, mas não define servidor, banco de dados nem
> infraestrutura. Por isso este aplicativo roda **inteiramente no navegador, sem back-end**: os dados ficam no
> `localStorage` e no `IndexedDB` do próprio navegador. Isso é suficiente para demonstrar e documentar os requisitos
> funcionais, mas **não** substitui uma implantação real (veja "Lacunas e limites").

## Como executar

Não há etapa de build nem dependências para *usar* o app.

**Opção 1 — abrir direto:** dê dois cliques em `index.html` (funciona via `file://`).

**Opção 2 — servidor local (recomendado):**

```bash
cd uniao-dos-trabalhadores
python3 -m http.server 8765        # ou: npx serve -l 8765
# abra http://localhost:8765/index.html
```

Use um navegador atual (Chrome, Edge, Firefox ou Safari). Microfone (mensagens de voz e chamadas) e geolocalização
pedem permissão do navegador; Web Crypto (hash de senha) exige `https://`, `localhost` ou `file://`.

### Contas de demonstração (dados fictícios)
Na tela **Entrar** há botões de acesso rápido. As senhas das contas fictícias são `demo123`.

| Conta | E-mail | Observação |
|---|---|---|
| Juliana Silva (Cliente) | `juliana@demo.com` | nome usado na Figura 2 do artigo |
| Carlos Oliveira (Profissional, cabeleireiro) | `carlos@demo.com` | nome usado na Figura 2 do artigo |

Os demais perfis, publicações, avaliações, pedidos e valores iniciais são **dados fictícios de demonstração** gerados
no primeiro acesso (datas relativas ao dia atual). **Não representam resultados de pesquisa nem usuários reais** e não
devem ser citados como tal no artigo. Em *Perfil → Configurações* é possível restaurar a demonstração ou apagar tudo e
começar vazio. As imagens das publicações de demonstração são ilustrações marcadas como "Imagem ilustrativa".

### Testar o "tempo real" e as chamadas
Abra **duas abas** do mesmo navegador e entre com usuários diferentes (a sessão é por aba). Mensagens, notificações,
pedidos e chamadas aparecem na outra aba sem recarregar (`BroadcastChannel` + evento `storage`).

## Tecnologias
- HTML5, CSS3 e JavaScript puro (ES2020), sem framework e sem build.
- Persistência: `localStorage` (dados) + `IndexedDB` (fotos, vídeos e áudios).
- Tempo real entre abas: `BroadcastChannel`. Chamada de voz: `WebRTC` (sinalização pelo `BroadcastChannel`).
- Mensagens de voz: `MediaRecorder`. Geolocalização: `navigator.geolocation`. Senhas: Web Crypto (PBKDF2-SHA-256 com sal).
- Ícones: Material Design Icons (Apache 2.0). Fonte: Inter (SIL OFL 1.1), empacotada em `assets/fonts` para uso offline.
- Testes e capturas: Node.js + Playwright (apenas desenvolvimento).

## Estrutura
```
index.html            ponto de entrada
css/style.css         estilos (responsivo, alto contraste, texto maior)
js/icons.js           ícones e logotipo
js/db.js              camada de dados, regras de negócio, semente de demonstração
js/ui.js              componentes reutilizáveis (cartões, estrelas, modal, toast…)
js/pages.js           telas
js/actions.js         ações, formulários e eventos
js/calls.js           chamadas de voz
js/app.js             roteador, estrutura (shell) e atualizações em tempo real
testes/               testes ponta a ponta (Playwright)
tools/capturas.js     gerador das capturas de tela
capturas/             capturas reais geradas (PNG 2x)
```

## Rastreabilidade: requisitos do artigo × implementação

| Req. | Situação | Onde ver no app |
|---|---|---|
| RF01 cadastro único | Atendido | Criar conta (valida e-mail único, senha ≥ 6, aceite dos termos) |
| RF02 escolher modo | Atendido | "Escolha seu modo"; *Perfil → Alternar para modo…* (ativa o perfil profissional na primeira vez) |
| RF03 interfaces por modo | Atendido | Barra: Cliente = Início/Buscar/Chat/Perfil; Profissional = Início/Chat/Agenda/Perfil (como na Figura 2) |
| RF04 modo sob o nome | Atendido | Cabeçalho, menu lateral e *Perfil* |
| RF05 busca por cidade | Atendido | *Buscar*: cidade, categoria, texto e ordenação; botão "Usar minha localização" |
| RF06 feed regional | Atendido | *Início* (cliente), filtrável por cidade e categoria |
| RF07 feed com fotos/vídeos | Atendido | Publicações com até 4 arquivos (imagem/vídeo ≤ 60 MB) |
| RF08 chat integrado | Atendido (voz) / parcial (chamadas) | Texto, mensagens de voz, chamada **de voz**; ver lacunas |
| RF09 curtidas, reações, comentários, compartilhamentos | Atendido | Reações (curtir, amei, parabéns, uau), comentários, compartilhar (copiar link ou enviar a um contato pelo chat) |
| RF10 divulgação pelo profissional | Atendido | *Início* (profissional) e *Publicações*: criar, editar legenda, excluir |
| RF11 avaliação por 5 estrelas | Atendido | Após o serviço concluído (*Meus pedidos → Avaliar*) |
| RF12 comentários do cliente | Atendido | Campo de comentário na avaliação |
| RF13 avaliações públicas no perfil | Atendido | Perfil público do profissional, com média e lista |
| RF14 agenda e horários | Atendido | *Agenda*: calendário, horários por dia da semana, bloquear dia, compromisso manual, pedidos |
| RF15 financeiro | Atendido | *Agenda → Financeiro*: semanal, mensal e anual; valor registrado ao concluir o serviço |
| RNF01/05/09 interface simples, navegação rápida, padronizada | Atendido (avaliação qualitativa) | Sem avaliação de usabilidade com usuários |
| RNF04 celular e computador | Atendido | Barra inferior no celular, menu lateral no computador |
| RNF07 tempo real | Atendido **entre abas** | Mensagens, notificações, pedidos, chamadas |
| RNF03/RNF08 segurança e armazenamento | **Parcial** | Senhas com PBKDF2 + sal; mídia em IndexedDB. **Sem criptografia dos dados**, sem servidor |
| RNF02/RNF06/RNF10 desempenho e acessos simultâneos | **Não verificável** | Exigem back-end e teste de carga; nada foi medido |

Complementos de acessibilidade (RNF01): link "Ir para o conteúdo", marcos semânticos, rótulos ARIA, foco visível,
opções **Texto maior** e **Alto contraste** (*Configurações*).

## Lacunas e decisões de interpretação (importante para o artigo)
1. **Sem back-end.** Dados só existem no navegador usado; "usuários diferentes" só se comunicam no mesmo navegador.
   Multiusuário real, e-mail, recuperação de senha e verificação de identidade exigem servidor (não especificado no artigo).
2. **Chamadas.** O artigo cita "chamadas"; foi implementada **chamada de voz** (WebRTC), funcionando apenas entre abas do
   mesmo navegador. **Chamada de vídeo não foi implementada**. Entre dispositivos exigiria servidor de sinalização (e TURN).
3. **Geolocalização.** O artigo pede pesquisa por "localização da cidade". Foi implementada seleção de cidade a partir de
   uma lista fixa (8 cidades) e "usar minha localização" que escolhe a cidade mais próxima por distância. Não há mapa nem
   geocodificação real.
4. **Menu "Políticas" (Figura 2).** O artigo não define o conteúdo. Há uma página com **texto-modelo**, sinalizada como
   tal; deve ser substituída por termos revisados.
5. **Menu do profissional.** A Figura 2 mostra Meu perfil, Serviços, Publicações, Agenda, Políticas, Configurações e Sair.
   Foram acrescentados Notificações e Ajuda (também no modo cliente) e o **Financeiro** (RF15) dentro da Agenda.
6. **Financeiro.** Valores são os **informados pelo profissional ao concluir** o serviço (estimativa, como no RF15);
   não há pagamento nem movimentação bancária no app.
7. **Contratação.** O artigo descreve pedido, execução e avaliação (Figura 1) sem detalhar estados. Foi adotado:
   pendente → agendado (aceito) → concluído, com recusa/cancelamento. Cliente só avalia serviços concluídos.
8. **Aparência × Figura 2.** Mantêm-se a paleta (roxo = cliente, verde = profissional), os menus e a estrutura de
   telas da Figura 2. O visual foi **ampliado**, com diferenças que devem constar na descrição do artigo:
   cabeçalho e faixa de título em degradê na cor do modo; barra inferior flutuante (celular) e menu lateral em
   degradê (computador); botões com brilho; avatares com anel; **modo escuro** (Configurações → Aparência:
   Automático, Claro, Escuro); e, no início do cliente, a faixa **"Mais bem avaliados"** (calculada a partir das
   avaliações existentes) e chips de categoria com ícone. Também: avatares são iniciais coloridas (sem fotos de
   pessoas), a fonte é Inter, e a cidade de Carlos Oliveira é Bragança–PA (na figura, São Paulo–SP).
9. **Exclusões.** Não há moderação de conteúdo, denúncia, bloqueio de usuários, pagamentos, nem aplicativo nativo.

## Testes (verificação realizada)
```bash
npm i -D playwright && npx playwright install chromium     # uma vez
python3 -m http.server 8765 &                              # servidor local
node testes/e2e.js              # fluxo principal com 2 usuários em 2 abas (29 verificações)
node testes/e2e-recursos.js     # validações, perfil, serviços, agenda, mídia, acessibilidade, layouts (28 verificações)
```
Os testes automatizados exercitam o aplicativo em Chromium (incluindo gravação de voz e chamada com dispositivos de
mídia simulados). **Foram executados apenas em Chromium**; Firefox e Safari não foram testados. Não houve teste com
usuários reais, de desempenho ou de carga.

## Capturas de tela para o artigo
```bash
node tools/capturas.js                  # regrava capturas/ (tema claro): celular 390×844 e computador 1440×900, escala 2x; 41 imagens
node tools/capturas.js --tema=escuro    # regrava capturas-escuro/ (mesmo roteiro e mesmos nomes, tema escuro)
```
As imagens são capturas reais da execução dos fluxos, sem moldura nem edição. `capturas/` está no tema claro e `capturas-escuro/` tem o mesmo roteiro no tema escuro (a numeração abaixo vale para as duas pastas). Sugestão de correspondência com o artigo:

| Seção do artigo | Capturas |
|---|---|
| 1. Cadastro | `01`–`03` |
| 2. Modo (cliente/profissional) | `04`, `05`, `28`, `33` |
| 3. Comunicação | `12`–`16` |
| Cliente: feed, busca, perfil público, contratação, avaliações | `06`–`11`, `29`–`32` |
| Profissional: painel, agenda, pedidos, financeiro, serviços, publicação | `17`–`27` |
| Acessibilidade, modo escuro e computador (RNF01/RNF04) | `34`–`41` (escuro: `35`–`37`) |

Observação: as capturas mostram dados fictícios de demonstração e identificam-se como protótipo; legende-as como tal.
